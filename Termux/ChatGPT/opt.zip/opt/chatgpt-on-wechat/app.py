# encoding:utf-8
import config
from channel import channel_factory
from common.log import logger

from plugins import *

# 🍎添加命令行参数，获取Sno
import os
import sys
import json

args = sys.argv[1:]
Sno = args[0]
PID=os.getpid()
path_json="./path.json"
try:
	with open(path_json, 'r', encoding='utf-8') as f:
		json_str = f.read()
		data = json.loads(json_str)
	total_file = data['root'] + data['total']
	user_dialog = data['root'] + data['control_tasks_name'] + "User_" + Sno + "/dialog.log"
	js = data['root'] + data['control_centre_name'] + "countToken.js"
	user_json = data['root'] + data['control_tasks_name'] + "User_" + Sno + "/user_" + Sno + ".json"
	user_path = data['root'] + data['control_tasks_name'] + "User_" + Sno + "/"
	master_json = data['root'] + data['control_centre_name'] + "config.json"
	project_path = data['root'] + data['project_name']
except FileNotFoundError:
	print("Erro，pid.json文件不存在！")
	sys.exit()

# 更新总pid文件，如果pid json文件不存在，先创建
try:
	# 打开total.json
	with open(total_file, 'r', encoding='utf-8') as f:
		json_str = f.read()
		data = json.loads(json_str)
	PID_list = data['PID']
	# 判断进程pid是否保存到json
	if PID not in PID_list:
		PID_list.append(PID)
		data["PID"] = PID_list
	# 保存pid对应的用户编码
	User="UserSno_" + str(PID)
	if not User in data:
		data[User] = int(Sno)
	# 保存编码对应的uid
	with open(user_json, 'r', encoding='utf-8') as f:
		json_str2 = f.read()
		data2 = json.loads(json_str2)
	Uid=data2['uid'][0]
	if not Uid in data:
		data[Uid]=int(Sno)
	# 保存数据
	with open(total_file, 'w', encoding='utf-8') as f:
		json.dump(data, f, ensure_ascii=False, indent=4)
except FileNotFoundError:
	data = {}  # 初始化一个空的字典对象
	with open(total_file, 'w') as f:
		json.dump(data, f)
	# 更新pid
	with open(total_file, 'r', encoding='utf-8') as f:
		json_str = f.read()
		data = json.loads(json_str)
	json_obj = json.loads(json_str)
	PID_list = [PID]
	data["PID"] = PID_list
	User="UserSno_" + str(PID)
	data[User] = int(Sno)
	# 保存编码对应的uid
	with open(user_json, 'r', encoding='utf-8') as f:
		json_str2 = f.read()
		data2 = json.loads(json_str2)
	Uid=data2['uid'][0]
	if not Uid in data:
		data[Uid]=int(Sno)
	# 保存数据
	with open(total_file, 'w', encoding='utf-8') as f:
		json.dump(data, f, ensure_ascii=False, indent=4)
# 更新用户配置文件pid
with open(user_json, 'r', encoding='utf-8') as f:
	json_str = f.read()
	data = json.loads(json_str)
data['PID']=PID
# 保存数据
with open(user_json, 'w', encoding='utf-8') as f:
	json.dump(data, f, ensure_ascii=False, indent=4)




def run():
    try:
        # load config
        config.load_config()

        # create channel
        channel_name='wx'
        channel = channel_factory.create_channel(channel_name)
        if channel_name=='wx':
            PluginManager().load_plugins()

        # startup channel
        channel.startup()
    except Exception as e:
        logger.error("App startup failed!")
        logger.exception(e)

if __name__ == '__main__':
    run()