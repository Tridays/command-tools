# encoding:utf-8
import itchat
from itchat.content import *
from bridge.reply import *
from bridge.context import *
from channel.channel import Channel
from concurrent.futures import ThreadPoolExecutor
from common.log import logger
from common.tmp_dir import TmpDir
from config import conf
from common.time_check import time_checker
from plugins import *
import requests
import io
# 获取文件序号，导入shell调用支持
from app import Sno,PID,user_dialog,js,user_json,master_json
import subprocess
import json
import datetime
import os
import time
import WxPusher

# 把响应体追加到文件
def writeToFile(text):
	with open(user_dialog, 'a') as f:
		f.write(text + "\n")

# TOKEN计费
def updateCount(text, TYPE):
	# 打开JSON文件并读取内容
	with open(user_json, 'r', encoding='utf-8') as f:
		json_str = f.read()
		data = json.loads(json_str)
	# 判断用户是否为付费用户
	Money_Limit = data['Money_Limit']
	if not Money_Limit :
		return
	
	if TYPE == "img" :
		TOKEN=8
		characters=8
		TOKEN_price=0.002 * TOKEN  # 每张图片固定0.016
	
	if TYPE == "text" :
		# 运行js，并获取TOKEN, characters
		result = subprocess.run(["node", js, text], capture_output=True, text=True)
		output_lines = result.stdout.strip().split("\n")
		TOKEN, characters = output_lines[-1].split()
		TOKEN = float(TOKEN)
		characters = float(characters)
		# 获取汇率字段的值
		rate = data['rate']
		# 计算 这串TOKEN所花费的人民币￥
		TOKEN_price=(0.002 * rate ) / 1000 * TOKEN
	
	print("TOKEN：", TOKEN , "\ncharacters：", characters)
	print("这串TOKEN所花费的人民币￥", round(TOKEN_price, 6))
	old_TOKEN = data['TOKEN']
	old_characters = data['characters']
	old_Remainder = data['Remainder']
	# 更新数值
	data['TOKEN'] = round(old_TOKEN + TOKEN, 6)
	data['characters'] = round(old_characters + characters, 6)
	data['Remainder'] = round(old_Remainder - TOKEN_price, 6)
	# 将修改后的数据写回json文件
	with open(user_json, 'w', encoding='utf-8') as f:
		json.dump(data, f, ensure_ascii=False, indent=4)

# 检查用户是否到期，余额是否用完
def check(receiver):
	# 打开用户配置文件并读取内容
	with open(user_json, 'r') as f:
		json_str = f.read()
		# 解析一个默认json
		data = json.loads(json_str)
		
	# 打开管理员配置文件并读取内容
	with open(master_json, 'r') as f:
		json_str2 = f.read()
		# 解析一个默认json
		data2 = json.loads(json_str2)
		
	# 获取用户信息
	name = data["name"]  # 客户姓名
	wx = data["wx"]  # 客户微信
	message = data["message"]  # 客户其他备注信息
	Money_Limit = data['Money_Limit']
	WX=data2['master_wx']  # 管理员的微信号
	Remainder = data['Remainder'] # 余额
	Regtime = data['Regtime'] # 注册时间
	Destiny = data['Destiny'] # 充值的天数
	Recharge = data['Recharge'] # 充值的金额
	TOKEN = data['TOKEN'] # TOKEN累积使用量
	AI_key_type = data['AI_key_type'] # api类型（public或private）
	Date_Limit = data['Date_Limit'] # 天数是否限制
	war = data['war'] # 可用天数≤5时，是否提醒用户
	
	# 判断是否为付费用户
	if Money_Limit :
		# 判断余额是否使用完
		if Remainder <= 0 :
			# 给用户提示
			itchat.send("尊敬的用户，您的注册时间为：" + str(Regtime) + "\n充值的天数为：" + str(Destiny) + " 天\n充值的金额为：" + str(Recharge) + " RMB\n账户余额：" + str(Remainder) + " RMB\nTOKEN累积使用量：" + str(TOKEN) + "\n\n自注册时间起30天内，您充值的金额已用完！您的AI服务已暂停，如需继续使用请联系管理员微信：" + str(WX) , toUserName=receiver)
			# 给管理者提示
			master_config=WxPusher.master_config
			with open(master_config, 'r', encoding='utf-8') as f:
				json_str = f.read()
				data = json.loads(json_str)
			# 获取管理员 WxPusher 的appToken和uid
			appToken = data['master_WxPusher_appToken']
			uid = data['master_WxPusher_uid']
			content = "<font size=5 color='red'>&emsp;&emsp;&emsp;&emsp;&emsp;账号停止服务提醒：</font>\n\n\n" + "User_" + str(Sno) + "\n\n\nname：" + str(name) + "\n\n\n微信号：" + str(wx) + "\n\n\n备注信息：" + str(message) + "\n\n\n注册时间：" + str(Regtime) + "\n\n\n充值金额：" + str(Recharge) + "\n\n\n账户余额：" + str(Remainder) + "&emsp;RMB" + "\n\n\n充值的天数：" + str(Destiny) + "\n\n\nTOKEN累积使用量：" + str(TOKEN) + "\n\n\nAI_key_type：" + str(AI_key_type) + "\n\n\n<font color='red'>原因：余额不足！</font>"
			summary = "User_" + Sno + "可用账号余额已使用完"
			WxPusher.WxPusher(appToken, content, summary, uid)
			time.sleep(5)
			os.system("kill -9 " + str(PID))
	
	# 判断是超过30天
	if Date_Limit:
		end_time = datetime.datetime.strptime(Regtime, '%Y-%m-%d %H:%M:%S')
		now = datetime.datetime.now()
		# 判断天数是否≤5天，并提示用户
		if (now - end_time).days >= Destiny - 5:
			if not war:
				itchat.send("尊敬的用户，您的注册时间为：" + str(Regtime) + "\n充值的天数为：" + str(Destiny) + "天\n充值的金额为：" + str(Recharge) + " RMB\n账户余额：" + str(Remainder) + " RMB" + "\nTOKEN累积使用量：" + str(TOKEN) + "\n\n自注册时间起，您的可以天数剩余5天！\n\n本消息不收费" , toUserName=receiver)
				data["war"] = True
				# 保存数据
				with open(user_json, 'w', encoding='utf-8') as f:
					json.dump(data, f, ensure_ascii=False, indent=4)
				# 给管理者提示
				master_config=WxPusher.master_config
				with open(master_config, 'r', encoding='utf-8') as f:
					json_str = f.read()
					data = json.loads(json_str)
				# 获取管理员 WxPusher 的appToken和uid
				appToken = data['master_WxPusher_appToken']
				uid = data['master_WxPusher_uid']
				content = "<font size=5 color='red'>&emsp;&emsp;账号可用天数小于5天提醒：</font>\n\n\n" + "User_" + Sno + "\n\n\nname：" + str(name) + "\n\n\n微信号：" + str(wx) + "\n\n\n备注信息：" + str(message) + "\n\n\n注册时间：" + str(Regtime) + "\n\n\n充值金额：" + str(Recharge) + "&emsp;RMB" + "\n\n\n账户余额：" + str(Remainder) + "&emsp;RMB" + "\n\n\n充值的天数：" + str(Destiny) + "&emsp;天\n\n\nTOKEN累积使用量：" + str(TOKEN) + "\n\n\nAI_key_type：" + str(AI_key_type) + "\n\n\n<font color='red'>该账号可用天数小于5天！</font>"
				summary = "User_" + Sno + "账号可用天数小于5天"
				WxPusher.WxPusher(appToken, content, summary, uid)
		# 判断天数是否用完
		if (now - end_time).days >= Destiny:
			itchat.send("尊敬的用户，您的注册时间为：" + str(Regtime) + "\n充值的天数为：" + str(Destiny) + " 天\n充值的金额为：" + str(Recharge) + " RMB\n账户余额：" + str(Remainder) + " RMB\nTOKEN累积使用量：" + str(TOKEN) + "\n\n自注册时间起，您充值的天数已用完！您的AI服务已暂停，如需继续使用请联系管理员微信：" + str(WX) , toUserName=receiver)
			# 给管理者提示
			master_config=WxPusher.master_config
			with open(master_config, 'r', encoding='utf-8') as f:
				json_str = f.read()
				data = json.loads(json_str)
			# 获取管理员 WxPusher 的appToken和uid
			appToken = data['master_WxPusher_appToken']
			uid = data['master_WxPusher_uid']
			content = "<font size=5 color='red'>&emsp;&emsp;&emsp;&emsp;&emsp;账号停止服务提醒：</font>\n\n\n" + "User_" + Sno + "\n\n\nname：" + str(name) + "\n\n\n微信号：" + str(wx) + "\n\n\n备注信息：" + str(message) + "\n\n\n注册时间：" + str(Regtime) + "\n\n\n充值金额：" + str(Recharge) + "\n\n\n账户余额：" + str(Remainder) + "&emsp;RMB" + "\n\n\n充值的天数：" + str(Destiny) + "\n\n\nTOKEN累积使用量：" + str(TOKEN) + "\n\n\nAI_key_type：" + str(AI_key_type) + "\n\n\n<font color='red'>原因：账号到期！</font>"
			summary = "User_" + Sno + "账号到期"
			WxPusher.WxPusher(appToken, content, summary, uid)
			time.sleep(5)
			os.system("kill -9 " + str(PID))

	

