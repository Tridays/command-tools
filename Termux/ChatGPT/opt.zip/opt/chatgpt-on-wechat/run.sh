cd /data/data/com.termux/files/usr/opt/chatgpt-on-wechat
echo "$$" > /data/data/com.termux/files/home/.cache/chatgpt/pid
python3 /data/data/com.termux/files/usr/opt/chatgpt-on-wechat/app.py
