import requests
import json
import logging
import sys
from app import Sno,PID,user_dialog,js,user_json,master_json,path_json,user_path,project_path
from common.log import logger

QR_file = "./QR.png"

def yinhua_img_up(QR_file):
	api="https://img.ink/api/upload"
	data = {
		'image': (QR_file, open(QR_file, 'rb'), 'image/png')
	}
	response = requests.post(api, files=data)
	if response.status_code == 200:
		result=response.json()
		img_url=result["data"]["url"]
		#print(img_url)
		return "![img](" + img_url + ") \n" + "二维码图片链接：（<font color='red'>你可以使用电脑打开二维码链接，然后手机扫码登陆！</font>）" + img_url 
	else:
		logger.info("Error sending request:", response.status_code, response.text)



def WxPusher(appToken, content, summary, uids):
	api = 'https://wxpusher.zjiecode.com/api/send/message'
	headers = {'content-type': 'application/json'}
	payload = {
		"appToken": appToken,
		"content": content,
		"summary": summary,
		"contentType": 3,
		"topicIds": [],
		"uids": uids,
		"url": "https://wxpusher.zjiecode.com",
		"verifyPay": False
	}
	response = requests.post(api, data=json.dumps(payload), headers=headers)
	if response.status_code == 200:
		logger.info(response.json())
	else:
		logger.info("Error sending request:", response.status_code, response.text)












