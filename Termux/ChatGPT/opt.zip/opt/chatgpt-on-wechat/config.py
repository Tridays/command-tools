# encoding:utf-8

import json
import os
from common.log import logger

# 将所有可用的配置项写在字典里
available_setting ={
    #openai api配置
    "open_ai_api_key": "", # openai api key
    "open_ai_api_base": "https://api.openai.com/v1", # openai apibase，当use_azure_chatgpt为true时，需要设置对应的api base
    "proxy": "", # openai使用的代理
    "model": "gpt-3.5-turbo", # chatgpt模型， 当use_azure_chatgpt为true时，其名称为Azure上model deployment名称
    "use_azure_chatgpt": False, # 是否使用azure的chatgpt

    #Bot触发配置
    "single_chat_prefix": ["bot", "@bot"], # 私聊时文本需要包含该前缀才能触发机器人回复
    "single_chat_reply_prefix": "[bot] ", # 私聊时自动回复的前缀，用于区分真人
    "group_chat_prefix": ["@bot"], # 群聊时包含该前缀则会触发机器人回复
    "group_chat_reply_prefix": "", # 群聊时自动回复的前缀
    "group_chat_keyword": [], # 群聊时包含该关键词则会触发机器人回复
    "group_at_off": False, # 是否关闭群聊时@bot的触发
    "group_name_white_list": ["ChatGPT测试群", "ChatGPT测试群2"], # 开启自动回复的群名称列表
    "group_name_keyword_white_list": [], # 开启自动回复的群名称关键词列表
    "group_chat_in_one_session": ["ChatGPT测试群"], # 支持会话上下文共享的群名称
    "image_create_prefix": ["画", "看", "找"], # 开启图片回复的前缀
    
    #chatgpt会话参数
    "expires_in_seconds": 3600, # 无操作会话的过期时间
    "character_desc": "你是ChatGPT, 一个由OpenAI训练的大型语言模型, 你旨在回答并解决人们的任何问题，并且可以使用多种语言与人交流。", # 人格描述
    "conversation_max_tokens": 1000, # 支持上下文记忆的最多字符数
            
    #chatgpt限流配置
    "rate_limit_chatgpt": 20, # chatgpt的调用频率限制
    "rate_limit_dalle": 50, # openai dalle的调用频率限制


    #chatgpt api参数 参考https://platform.openai.com/docs/api-reference/chat/create
    "temperature": 0.9,
    "top_p": 1,
    "frequency_penalty": 0,
    "presence_penalty": 0,

    #语音设置
    "speech_recognition": False, # 是否开启语音识别
    "voice_reply_voice": False, # 是否使用语音回复语音，需要设置对应语音合成引擎的api key
    "voice_to_text": "openai", # 语音识别引擎，支持openai和google
    "text_to_voice": "baidu", # 语音合成引擎，支持baidu和google

    # baidu api的配置， 使用百度语音识别和语音合成时需要
    'baidu_app_id': "",
    'baidu_api_key': "",
    'baidu_secret_key': "",

    #服务时间限制，目前支持itchat
    "chat_time_module": False, # 是否开启服务时间限制
    "chat_start_time": "00:00", # 服务开始时间
    "chat_stop_time": "24:00", # 服务结束时间

    # itchat的配置
    "hot_reload": False, # 是否开启热重载

    # wechaty的配置
    "wechaty_puppet_service_token": "", # wechaty的token

    # chatgpt指令自定义触发词
    "clear_memory_commands": ['#清除记忆'], # 重置会话指令


}

class Config(dict):
    def __getitem__(self, key):
        if key not in available_setting:
            raise Exception("key {} not in available_setting".format(key))
        return super().__getitem__(key)

    def __setitem__(self, key, value):
        if key not in available_setting:
            raise Exception("key {} not in available_setting".format(key))
        return super().__setitem__(key, value)

    def get(self, key, default=None):
        try :
            return self[key]
        except KeyError as e:
            return default
        except Exception as e:
            raise e
    
config = Config()

def load_config():
    global config
    config_path = "./config.json"
    if not os.path.exists(config_path):
        logger.info('配置文件不存在，将使用config-template.json模板')
        config_path = "./config-template.json"

    config_str = read_file(config_path)
    # 将json字符串反序列化为dict类型
    config = Config(json.loads(config_str))

    # override config with environment variables.
    # Some online deployment platforms (e.g. Railway) deploy project from github directly. So you shouldn't put your secrets like api key in a config file, instead use environment variables to override the default config.
    for name, value in os.environ.items():
        if name in available_setting:
            logger.info("[INIT] override config by environ args: {}={}".format(name, value))
            config[name] = value

    logger.info("[INIT] load config: {}".format(config))



def get_root():
    return os.path.dirname(os.path.abspath( __file__ ))


def read_file(path):
    with open(path, mode='r', encoding='utf-8') as f:
        return f.read()


def conf():
    return config
