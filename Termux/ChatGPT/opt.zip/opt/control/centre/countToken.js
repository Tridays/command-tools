
//脚本作用：统计TOKEN的数量
const { encode } = require('gpt-3-encoder')

// 获取命令行参数
const inputText = process.argv[2];

// 对输入文本进行编码
const encodedText = encode(inputText)

// 计算TOKEN数量和字符数量
const tokenCount = encodedText.length;
const charCount = inputText.length;

// 输出结果
console.log(`${tokenCount} ${charCount}`);
