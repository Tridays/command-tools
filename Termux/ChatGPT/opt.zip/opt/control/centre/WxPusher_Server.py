from flask import Flask, request
import json
import sys
import datetime
import os
import requests
import time

root="/opt/"
centre=root + "control/centre/"
tasks=root + "control/tasks/"
project_path=root + "chatgpt-on-wechat/"
master_file=centre + "config.json"
total_file =tasks + "total.json"
PID=os.getpid()

try:
	with open(total_file, 'r', encoding='utf-8') as f:
		json_str = f.read()
		data = json.loads(json_str)
	data['WxPusher']=PID
	# 保存数据
	with open(total_file, 'w', encoding='utf-8') as f:
		json.dump(data, f, ensure_ascii=False, indent=4)
except FileNotFoundError:
	print("Erro，total.json文件不存在！")
	sys.exit()




with open(master_file, 'r', encoding='utf-8') as f:
	json_str = f.read()
	data = json.loads(json_str)
# 获取管理员 WxPusher 的appToken，wx,master_WxPusher_appid
appToken=data['master_WxPusher_appToken']
master_uid=data['master_WxPusher_uid']
master_wx=data['master_wx']
master_WxPusher_appid=data['master_WxPusher_appid']
extra="\n\n\n您可以给公众号发送指令：\n\n\n\#" + master_WxPusher_appid + " 登陆\n\n\n\#" + master_WxPusher_appid + " 退出\n\n\n\#" + master_WxPusher_appid + " 余额\n\n\n其他事项：为保证服务稳定，服务器资源合理利用，限制指令6条/每间隔20分钟"

# WxPusher
def WxPusher(appToken, content, summary, uids):
	api = 'https://wxpusher.zjiecode.com/api/send/message'
	headers = {'content-type': 'application/json'}
	payload = {
		"appToken": appToken,
		"content": content,
		"summary": summary,
		"contentType": 3,
		"topicIds": [],
		"uids": uids,
		"url": "https://wxpusher.zjiecode.com",
		"verifyPay": False
	}
	response = requests.post(api, data=json.dumps(payload), headers=headers)
	if response.status_code == 200:
		print(response.json())
	else:
		print("Error sending request:", response.status_code, response.text)


# 判断是否为本地用户
def is_user(uid):
	# 打开total.json
	with open(total_file, 'r', encoding='utf-8') as f:
		json_str = f.read()
		data = json.loads(json_str)
	# 判断uid是否存在
	if uid in data:
		return True
	else:
		return False

# 判断用户是否频繁请求
def is_overclock(uid):
	# 打开total.json
	with open(total_file, 'r', encoding='utf-8') as f:
		json_str = f.read()
		data = json.loads(json_str)
	Sno=data[uid]
	user_file=tasks + "User_" + str(Sno) + "/user_" + str(Sno) + ".json"
	# 打开用户配置
	with open(user_file, 'r', encoding='utf-8') as f:
		json_str = f.read()
		data = json.loads(json_str)
	# 用户上次请求的时间
	specified_time_str = data['Check_Remainder']
	# 用户请求的次数
	request_times = data['request_times']
	# 获取当前时间
	now = datetime.datetime.now()
	# 将指定时间字符串解析为 datetime 对象
	specified_time = datetime.datetime.strptime(specified_time_str, '%Y-%m-%d %H:%M:%S')
	# 加上20分钟
	specified_time = specified_time + datetime.timedelta(minutes=20)
	# 时间大于20分钟，请求次数<6次
	if now > specified_time and request_times < 6:
		data['request_times'] = request_times + 1
		s1=0
		
	# 时间大于20分钟，请求次数=7（恢复请求）)
	if now > specified_time and request_times == 7:
		data['request_times'] = 1
		s1=0
	
	# 时间小于20分钟，请求次数>6（拒绝请求）)
	if now < specified_time and request_times > 6:
		s1=1
	
	# 时间大于20分钟，请求次数=6次（允许的最后一个请求）
	if now > specified_time and request_times == 6:
		current_time = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())
		data['Check_Remainder']=current_time
		data['request_times'] = request_times + 1
		s1=0
		
	# 保存数据
	with open(user_file, 'w', encoding='utf-8') as f:
		json.dump(data, f, ensure_ascii=False, indent=4)	
	if s1 == 0:
		return Sno,True
	else:
		return Sno,False

def is_pid(Sno):
	# 打开用户配置
	user_file = tasks + "User_" + str(Sno) + "/user_" + str(Sno) + ".json"
	with open(user_file, 'r', encoding='utf-8') as f:
		json_str = f.read()
		data = json.loads(json_str)
	pid=data['PID']
	try:
		os.kill(pid, 0)
		return True
	except OSError:
		return False


# 登陆账号
def user_login(userName, uid, Sno):
	# 判断用户进程是否存在
	if is_pid(Sno) :
		print("User_" + str(Sno) + " 用户进程存在!")
		content = "<font size=5 color='red'>&emsp;&emsp;&emsp;&emsp;&emsp;账号状态提示</font>\n\n\n<font size=5 color='red'>尊敬的用户您的账号服务已启动！请不要重复登陆，如有其他问题，请联系管理员处理：" + master_wx + "</font>\n\n\n" + extra
		summary = "账号状态提示"
		WxPusher(appToken, content, summary, [uid])
		return
	user_file = tasks + "User_" + str(Sno) + "/user_" + str(Sno) + ".json"
	with open(user_file, 'r', encoding='utf-8') as f:
		json_str = f.read()
		data = json.loads(json_str)
	json_data = data['config'][0]
	# 保存数据
	run_file = project_path + "config.json"
	with open(run_file, 'w', encoding='utf-8') as f:
		json.dump(json_data, f, ensure_ascii=False, indent=4)
	# 运行程序
	#app=project_path + "app.py"
	cmd="cd " + project_path + "; nohup python3 " + " app.py " + str(Sno) + " > " + tasks + "User_" + str(Sno) + "/dialog.log" + " &" 
	#print(cmd)
	os.system(cmd)
	now = datetime.datetime.now()
	print(now , "：Login --->用户：" , userName , "，编码：" , str(Sno) , " 请求登陆账号")

# 账号退出
def user_exit(userName, uid, Sno):
	user_file = tasks + "User_" + str(Sno) + "/user_" + str(Sno) + ".json"
	with open(user_file, 'r', encoding='utf-8') as f:
		json_str = f.read()
		data = json.loads(json_str)
	user_uid=data['uid']
	user_pid=data['PID']
	cmd="kill -9 " + str(user_pid)
	os.system(cmd)
	content = "<font size=5 color='red'>&emsp;&emsp;&emsp;&emsp;&emsp;账号退出提示</font>\n\n\n<font size=5 color='red'>尊敬的用户您的账号已退出！，如有其他问题，请联系管理员处理：" + master_wx + "</font>\n\n\n" + extra
	summary = "账号退出提示"
	WxPusher(appToken, content, summary, user_uid)
	now = datetime.datetime.now()
	print(now , "：Exit --->用户：" , userName , "，编码：" , Sno , " 请求退出账号")
	
# 反馈用户余额
def reply_Remainder(userName, uid, Sno):
	user_file = tasks + "User_" + str(Sno) + "/user_" + str(Sno) + ".json"
	with open(user_file, 'r', encoding='utf-8') as f:
		json_str = f.read()
		data = json.loads(json_str)
	user_uid=data['uid']
	Regtime=data['Regtime']
	Destiny=data['Destiny']
	Recharge=data['Recharge']
	Remainder=data['Remainder']
	TOKEN=data['TOKEN']
	Server_fees=data['Server_fees']

	content="尊敬的用户：\n\n\n您的注册时间为：" + str(Regtime) + "\n\n\n充值的天数为：" + str(Destiny) + " 天\n\n\n充值的金额为：" + str(Recharge) + " RMB\n\n\n服务技术费用："  + str(Server_fees) + " RMB\n\n\n账户余额：" + str(Remainder) + " RMB\n\n\nTOKEN累积使用量：" + str(TOKEN) + "\n\n\n如有其他问题，请联系管理员处理：" + str(master_wx) + extra
	summary = "账号余额提示"
	WxPusher(appToken, content, summary, user_uid)
	now = datetime.datetime.now()
	print(now , "：Check￥ --->用户：" , userName , "，编码：" , Sno , " 请求查询余额")

def reply_no_user(uid):
	content = "<font size=5 color='red'>&emsp;&emsp;&emsp;&emsp;&emsp;登陆提示</font>\n\n\n<font size=3 color='green'>抱歉！未找到您的配置信息，请联系管理员处理：" + str(master_wx) + "</font>\n"
	summary = "登陆提示"
	WxPusher(appToken, content, summary, [uid])






app = Flask(__name__)
@app.route('/', methods=['POST'])
def handle_request():
	json_data = request.get_json()
	if json_data is not None and 'action' in json_data and json_data['action'] == 'send_up_cmd' and 'data' in json_data:
		data = json_data['data']
		# 获取用户请求信息
		if 'userName' in data and 'content' in data:
			appId = data['appId']
			appName = data['appName']
			content = data['content'].strip()
			uid = data['uid'].strip()
			userName = data['userName']
			# print(userName)
			# print(uid)
			# print(content)
			
			
			if content == "登陆":
				if is_user(uid):
					# Sno 编号， b 为True可以请求
					Sno,b = is_overclock(uid)
					if b :
						user_login(userName, uid, Sno)
				else:
					reply_no_user(uid)
			
			if content == "退出":
				if is_user(uid):
					# Sno 编号， b 为True可以请求
					Sno,b = is_overclock(uid)
					if b :
						user_exit(userName, uid, Sno)
				else:
					reply_no_user(uid)
				
				
			if content == "余额":
				if is_user(uid):
					# Sno 编号， b 为True可以请求
					Sno,b = is_overclock(uid)
					if b :
						reply_Remainder(userName, uid, Sno)
				else:
					reply_no_user(uid)
				
		else:
			print('Invalid JSON data')
	# 用户关注
	elif json_data is not None and 'action' in json_data and json_data['action'] == 'app_subscribe' and 'data' in json_data:
		data = json_data['data']
		# 获取用户请求信息
		if 'userName' in data and 'uid' in data:
			appId=data['appId']
			appName = data['appName']
			user_uid = data['uid']
		content = "<font size=5 color='red'>&emsp;&emsp;&emsp;&emsp;&emsp;新用户关注提示</font>\n\n\n<font size=5 color='red'>新用户关注的频道为：" + str(appId) + "\n\n\n新用户的uid为：</font>\n\n\n<font size=4 color='red'>" + str(user_uid) + "</font>\n"
		summary = "新用户关注提示"
		WxPusher(appToken, content, summary, master_uid)
	else:
		print('接收失败')
	print('OK')

if __name__ == '__main__':
	app.run(host='0.0.0.0', port=1020)





