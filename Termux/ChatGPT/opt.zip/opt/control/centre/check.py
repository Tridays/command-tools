import json
from datetime import datetime, timedelta
import os
import sys
import time
import requests
root="/opt/"
centre=root + "control/centre/"
tasks=root + "control/tasks/"
project_path=root + "chatgpt-on-wechat/"
master_file=centre + "config.json"
total_json =tasks + "total.json"
with open(master_file, 'r', encoding='utf-8') as f:
	json_str = f.read()
	data = json.loads(json_str)
# 获取管理员 WxPusher 的appToken，wx,master_WxPusher_appid
appToken=data['master_WxPusher_appToken']
master_uid=data['master_WxPusher_uid']
master_wx=data['master_wx']
master_WxPusher_appid=data['master_WxPusher_appid']
PID=os.getpid()


# 更新总pid文件，如果pid json文件不存在，先创建
try:
	# 打开total.json
	with open(total_json, 'r', encoding='utf-8') as f:
		json_str = f.read()
		data = json.loads(json_str)
	# 判断进程pid是否保存到json
	if PID not in data:
		current_time = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())
		data['check_PID']=PID		
		data['check_survive_time']=current_time # 上次存活的时间
	# 保存数据
	with open(total_json, 'w', encoding='utf-8') as f:
		json.dump(data, f, ensure_ascii=False, indent=4)
except FileNotFoundError:
	data = {}  # 初始化一个空的字典对象
	data = json.loads(data)
	# 更新pid
	if PID not in data:
		current_time = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())
		data['check_PID']=PID		
		data['check_survive_time']=current_time  # 上次存活的时间
	# 保存数据
	with open(total_json, 'w', encoding='utf-8') as f:
		json.dump(data, f, ensure_ascii=False, indent=4)



# 判断用户的进程
def is_pid(pid):
	try:
		os.kill(pid, 0)
		return True
	except OSError:
		return False

    

# WxPusher
def WxPusher(appToken, content, summary, uids):
	api = 'https://wxpusher.zjiecode.com/api/send/message'
	headers = {'content-type': 'application/json'}
	payload = {
		"appToken": appToken,
		"content": content,
		"summary": summary,
		"contentType": 3,
		"topicIds": [],
		"uids": uids,
		"url": "https://wxpusher.zjiecode.com",
		"verifyPay": False
	}
	response = requests.post(api, data=json.dumps(payload), headers=headers)
	if response.status_code == 200:
		print(response.json())
	else:
		print("Error sending request:", response.status_code, response.text)



# WxPusher是否存活
def WxPusher_is_survive():
	with open(total_json, 'r', encoding='utf-8') as f:
		json_str = f.read()
		data = json.loads(json_str)
	WxPusher_pid=data['WxPusher']
	if is_pid(WxPusher_pid):
		return 
	else:
		cmd="cd " + centre + "; nohup python3 " + " WxPusher_Server.py " + " > " + tasks + "WxPusher_Server.log" + " &" 
		#print(cmd)
		os.system(cmd)
		content="<font size=5 color='red'>&emsp;&emsp;&emsp;&emsp;&emsp;紧急通知！</font>\n\n\n<font size=3 color='red'>check已自动重启WxPusher_Server后台服务，请人工检查进程是否存在，否则用户无法使用公众号指令：登陆、退出、查余额等等功能！</font>"
		summary = "WxPusher_Server后台服务掉线提示！"
		WxPusher(appToken, content, summary, master_uid)

# check进程自我监测
def check_is_survive():
	with open(total_json, 'r', encoding='utf-8') as f:
		json_str = f.read()
		data = json.loads(json_str)
	check_survive_time=data['check_survive_time']
	# 将时间字符串转换为datetime对象
	x_datetime = datetime.strptime(check_survive_time, '%Y-%m-%d %H:%M:%S')
	# 获取当前时间
	now = datetime.now()
	# 计算当前时间与变量x保存的时间之间的差异
	time_difference = now - x_datetime
	# 定义3小时的时间差
	three_hours = timedelta(hours=3)
	# 比较时间差是否大于3小时
	if time_difference > three_hours:
		data['check_survive_time']=time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())
		# 保存数据
		with open(total_json, 'w', encoding='utf-8') as f:
			json.dump(data, f, ensure_ascii=False, indent=4)
		content="<font size=5 color='red'>&emsp;&emsp;&emsp;&emsp;&emsp;check后台服务提示！</font>\n\n\n<font size=3 color='red'>check后台服务提示（每3小时/次），目的是告知check服务未掉线！如果超过3小时未收到此类信息，请注意检查check运行情况！有可能掉线！会造成资源无法及时更新！</font>"
		summary = "check后台服务提示！"
		WxPusher(appToken, content, summary, master_uid)
	

# 处理pid
def dispose_pid():
	with open(total_json, 'r', encoding='utf-8') as f:
		json_str = f.read()
		# 解析一个默认json
		data = json.loads(json_str)
		# 解析一个固定列表
		json_obj = json.loads(json_str)
	PID_list = json_obj['PID']
	# 判断列表是否为空
	if int(len(PID_list)) == 0:
		print("pid列表为空！没有任何进程在运行")
		return
	# 定义一个存储掉线的pid的临时json
	pid_json = '{}'
	pid_json = json.loads(pid_json)

	for x in PID_list:
		if not is_pid(x) :
			print(x)
			#  把掉线用户从total.json去除
			data['PID'].remove(x)
			# 把掉线用户添加到pid_json
			if "UserSno_" + str(x) in json_obj:
				Sno = json_obj["UserSno_" + str(x)]
				pid_json["User_" +str(Sno)]=x
			# 并且删除对应用户
			User="UserSno_" + str(x)
			if User in data:
				del data[User]
	# # 保存数据
	# with open(total_json, 'w', encoding='utf-8') as f:
	# 	json.dump(data, f, ensure_ascii=False, indent=4)
	# 获取所有键名
	keys = pid_json.keys()
	# 输出所有键名
	s=""
	for key in keys:
		s += "\n\n\n" + key 
	# 通知管理员
	content="<font size=5 color='red'>&emsp;&emsp;&emsp;&emsp;&emsp;用户掉线通知！</font>\n\n\n<font size=3 color='red'>请注意最近有如下用户掉线或退出登陆</font>" + s
	summary = "用户掉线通知！"
	WxPusher(appToken, content, summary, master_uid)



# 主函数
def Main():
	#WxPusher_is_survive()
	dispose_pid()
	check_is_survive()


while True:
	try:
		Main()
	except:
		print("出现异常！")
		raise Exception
	time.sleep(300)  # 暂停程序5分钟 300秒 = 5分钟



