local utils = require("plugins/utils")
local keymap = vim.keymap.set  -- 使用 keymap代替vim.keymap


-----------------------------------------基础快捷键绑定-----------------------------------------
-- 设置主键为空格（主键功能非常强大）
vim.g.mapleader = " "
-- ---------- 插入模式 ---------- --
keymap("i", "jk", "<ESC>") -- 说明，i代表插入模式，使用jk代替ESC键
-- ---------- 视觉模式 ---------- --
-- 单行或多行移动
keymap("v", "J", ":m '>+1<CR>gv=gv")  --下移某行或选中
keymap("v", "K", ":m '>-2<CR>gv=gv")  --上移某行或选中
-- ---------- 正常模式 ---------- --
-- 窗口（分屏）
keymap("n", "<leader>sv", "<C-w>v") -- 水平新增窗口
keymap("n", "<leader>sh", "<C-w>s") -- 垂直新增窗口
-- 取消高亮
--keymap("n", "<leader>nh", ":nohl<CR>")
-- ---------- 插件 ---------- --
-- 切换buffer（页面）
keymap("n", "<C-L>", ":bnext<CR>")  
keymap("n", "<C-H>", ":bprevious<CR>")  
-- ---------- 反悔操作😅 ---------- --
keymap({"n", "i", "v"}, "<C-z>", "<ESC>u<ESC>i")  --为撤回操作添加快捷键
keymap({"n", "i"}, "<C-y>", "<ESC><C-R><ESC>i")  

--自由选中
keymap({"v", "i", "n"}, "<C-A>", "<ESC>v")
--全选
keymap({"v", "i", "n"}, "<C-a>", "<ESC>ggVG")
--快速选中，光标到下一行
keymap({"v", "i", "n"}, "<C-sj>", "<ESC>vj")
--快速选中，光标到本行末（失败）
--keymap({"v", "i", "n"}, "<C-on>", "<ESC>v$") --本来v$就够了，这样子用好像要多加$
--快速选中，光标到本行首（失败）
--keymap({"v", "i", "n"}, "<C-os>", "<ESC>v0") --本来v$就够了，这样子用好像要多加$
--快速选中，选择光标到下一个单词/字符之前
keymap({"v", "i", "n"}, "<C-se>", "<ESC>ve") --本来v$就够了，这样子用好像要多加$
--提供更多选中选择
keymap({"v", "i", "n"}, "<C-x>", '<Cmd>lua require("which-key").show("v", {mode = "n", auto = true})<CR>')
--取消选中
keymap({"v"}, "<ESC>", "V")
--复制
keymap({"v", "i", "n"}, "<C-c>", "y<ESC>i")
--粘贴
keymap({"v", "i", "n"}, "<C-v>", "<ESC>v<CR>p<ESC>i")
--删除一行
keymap({"v", "i", "n"}, "<C-D>", "<ESC>dd<ESC>i")
--删除选中
keymap({"v", "i", "n"}, "<C-d>", "d<ESC>i")
keymap({"v", "i", "n"}, "<backspace>", "d<ESC>i")
--保存文件
keymap({"v", "i", "n"}, "<C-s>", "<ESC>:w!<CR>i")
--跳到到文本开头
--keymap({"v", "i", "n"}, "<C-g>", "<ESC>gg")
--跳到到文本末尾
keymap({"v", "i", "n"}, "<C-G>", "<ESC>G<CR>i")
vim.cmd[[
" 取消使用空格代替Tab键
set noexpandtab
]]




--[[
------------------nvim-jdtls提供的API------------------
 *jdtls.start_or_attach*
	启动语言服务器（如果未启动），并附加当前缓冲区。
*jdtls.organize_imports*
	在当前缓冲区中组织导入
 *jdtls.compile*🍎
	编译 Java 工作区如果存在编译错误，它们将显示在快速修复列表中。
*jdtls.build_projects*🍎
	触发一个或多个项目的重新生成。
 *jdtls.update_project_config*🍎
	更新项目配置（从 Gradle 或 Maven）。在多模块项目中，这只会更新当前缓冲区的模块。
*jdtls.update_projects_config*
	M.update_projects_config（{opts}）
	处理对一个或多个项目的 Gradle 或 Maven 配置所做的更改。需要 eclipse.jdt.ls >= 1.13.0
*jdtls.extract_constant*🍎
	从游标下的表达式中提取常量
 *jdtls.extract_variable*🍎
	从游标下的表达式中提取变量
*jdtls.extract_variable_all*
	从光标下的表达式中提取局部变量并替换所有匹配项
*jdtls.extract_method*
	提取方法
 *jdtls.super_implementation*🍎
	跳转到光标下方法的超级实现
*jdtls.javap*
	在终端缓冲区中运行“javap”工具。基于当前项目设置类路径。
 *jdtls.jshell*
	在终端缓冲区中运行“jshell”工具。
	基于当前项目设置类路径。
*jdtls.jol*
	在终端缓冲区中运行“jol”工具以打印类布局
	您必须配置“jol_path”以指向“jol”jar 文件：
*jdtls.set_runtime*
	更改 Java 运行时的Java版本。
*jdtls.dap.test_class*
	调试当前缓冲区中的测试类
*jdtls.dap.test_nearest_method*
	调试当前缓冲区中最近的测试方法
*jdtls.dap.pick_test*
	M.pick_test（{opts}）
	提示运行当前缓冲区中的测试方法
*jdtls.dap.fetch_main_configs*
	M.fetch_main_configs（{opts}， {callback}
	发现项目中的可执行主要功能
*jdtls.dap.setup_dap_main_class_configs*
	M.setup_dap_main_class_configs（{opts}）
	发现项目中的主要类并设置|dap-configuration| Java 的条目。
*jdtls.dap.setup_dap*
	M.setup_dap（{opts}）
	注册|DAP-adapter|用于Java。需要 nvim-dap

------------------lsp提供的API------------------
*vim.lsp.buf.code_action（）*🍎
	选择当前光标位置可用的代码操作。
*vim.lsp.buf.completion（）*
	检索当前光标位置的完成项。只能是在插入模式下调用。
 *vim.lsp.buf.declaration（）*🍎
	跳转到光标下符号的声明。
*vim.lsp.buf.definition（）*  🍎
	跳转到光标下符号的定义。
*vim.lsp.buf.document_highlight（）*
	向服务器发送请求以解决当前文档突出显示的问题
	文本文档位置。此请求可以通过键映射或
	通过诸如“光标保持”之类的事件，例如：
>vim
autocmd CursorHold <buffer> lua vim.lsp.buf.document_highlight（）
autocmd CursorHoldI <buffer> lua vim.lsp.buf.document_highlight（）
autocmd CursorMoving <buffer> lua vim.lsp.buf.clear_references（）
<
*vim.lsp.buf.document_symbol（）*
	在快速修复窗口中列出当前缓冲区中的所有符号。
*vim.lsp.buf.execute_command（）*
	执行 LSP 服务器命令。
 *vim.lsp.buf.format（）*
	使用附加（和可选的筛选）语言设置缓冲区格式
 *vim.lsp.buf.hover（）*🍎
	显示注释文档，在浮动光标下方显示有关符号的悬停信息
	窗。调用该函数两次将跳转到浮动窗口。
*vim.lsp.buf.implementation（）*🍎
	跳转到实现｜接口，列出光标下符号的所有实现
	快速修复窗口。
*vim.lsp.buf.incoming_calls（）*
	在|的光标下列出符号的所有调用站点快速修复|
	窗。如果符号可以解析为多个项目，用户可以选择一个
*vim.lsp.buf.list_workspace_folders（）*
	列出工作区文件夹。
*vim.lsp.buf.outgoing_calls（）*
	列出由光标下的符号调用的所有项
*vim.lsp.buf.references（）*
	跳转到引用位置，列出对快速修复中光标下符号的所有引用窗。
*vim.lsp.buf.remove_workspace_folder（）*
	remove_workspace_folder（{workspace_folder}）
	从工作区文件夹中删除路径上的文件夹。如果 {路径} 不是
	但是，系统将使用 | 提示用户输入路径输入（）|.
vim.lsp.buf.rename（）*
	重命名光标下对符号的所有引用。
*vim.lsp.buf.server_ready（）*
	检查附加到当前缓冲区的语言服务器是否准备。如果服务器响应，则为“true”。
*vim.lsp.buf.type_definition（）*
	跳转到光标下符号类型的定义。
*vim.lsp.buf.workspace_symbol（）*
	在快速修复窗口中列出当前工作区中的所有符号。
*vim.lsp.util.open_floating_preview（）*
	open_floating_preview（{内容}， {语法}， {选择})
	在浮动窗口中显示内容。
*vim.lsp.buf.signature_help（）*
	在光标下方显示有关符号的签名信息浮动窗口。
-- 以浮窗形式显示错误
    vim.api.nvim_buf_set_keymap(bufnr, "n", "go", "<cmd>lua vim.diagnostic.open_float()<CR>", {silent = true, noremap = true})
    vim.api.nvim_buf_set_keymap(bufnr, "n", "gp", "<cmd>lua vim.diagnostic.goto_prev()<CR>", {silent = true, noremap = true})
    vim.api.nvim_buf_set_keymap(bufnr, "n", "gn", "<cmd>lua vim.diagnostic.goto_next()<CR>", {silent = true, noremap = true})
--]]
-----------------------------------------lsp服务器快捷键绑定-----------------------------------------
--lsp提供的功能太多了，这里就挑选一些常用的


lspKM = {
		name = "Lsp主功能｜",
		--nvim-jdt.ls提供
		a = {"<cmd>lua require('jdtls').extract_variable()<CR>", "从光标处转成变量", mode = "n",  noremap=true, silent=true },
		b = {"<cmd>lua require('jdtls').extract_constant()<CR>", "从光标处转成常量", mode = "n",  noremap=true, silent=true },
		c = {"<cmd>lua require'jdtls'.test_class()<CR>", "Run测试类", mode = "n",  noremap=true, silent=true },
		d = {"<cmd>lua require'jdtls'.test_nearest_method()<CR>", "Run测试类主方法", mode = "n",  noremap=true, silent=true },
		e = {"<cmd>lua require'jdtls'.super_implementation()<CR>", "跳转到光标下方法的超级实现", mode = "n",  noremap=true, silent=true },
		f = {"<cmd>lua require'jdtls'.compile()<CR>", "编译当前工作区", mode = "n",  noremap=true, silent=true },
		g = {"<cmd>lua require'jdtls'.build_projects()<CR>", "构建项目", mode = "n",  noremap=true, silent=true },
		h = {"<cmd>lua require'jdtls'.update_project_config()<CR>", "更新项目配置", mode = "n",  noremap=true, silent=true },
		
		--lsp提供
		i = {"<cmd>lua vim.lsp.buf.declaration()<CR>", "跳转到声明"},
		j = {"<cmd>lua vim.lsp.buf.definition()<CR>", "跳转到定义"},
		k = {"<cmd>lua vim.lsp.buf.hover()<CR>", "显示注释文档"},
		l = {"<cmd>lua vim.lsp.buf.implementation()<CR>", "跳转到实现｜接口"},
		m = {"<cmd>lua vim.lsp.buf.signature_help()<CR>", "显示签名信息"},
		n = {"<cmd>lua vim.lsp.buf.code_action()<CR>", "＊提供可用的代码操作codeAction", mode = "n",  noremap=true, silent=true },
		o = {"<cmd>lua require'jdtls'.set_runtime()<CR>", "指定Java版本Run", mode = "n",  noremap=true, silent=true },
		--help
		y =  {"<cmd>lua = vim.lsp.get_active_clients()<CR>", "查看当前Lsp配置情况"},
}
--添加java自动命令
vim.cmd([[
	command! -buffer -nargs=? -complete=custom,v:lua.require'jdtls'._complete_compile JdtCompile lua require('jdtls').compile(<f-args>)
	command! -buffer -nargs=? -complete=custom,v:lua.require'jdtls'._complete_set_runtime JdtSetRuntime lua require('jdtls').set_runtime(<f-args>)
	command! -buffer JdtUpdateConfig lua require('jdtls').update_project_config()
	command! -buffer JdtJol lua require('jdtls').jol()
	command! -buffer JdtBytecode lua require('jdtls').javap()
	command! -buffer JdtJshell lua require('jdtls').jshell()
]])




-----------------------------------------dap调试快捷键绑定-----------------------------------------
--dap快捷键
	
dapKM = {
	name = "Run｜调试",
	a = {"<cmd>lua require'dap'.toggle_breakpoint()<CR>", "设置断点<F9>", mode = { 'n', 'v'}, silent = true, noremap = true, buffer = bufnr},
	b = {"<cmd>lua require'dap'.continue()<CR>", "断点调试<F10>", mode = {'n', 'v'}, silent = true, noremap = true, buffer = bufnr},
	c = {"<cmd>lua require'dap'.step_over()<CR>", "单步执行代码step_over()<F4>", mode = { 'n', 'v'}, silent = true, noremap = true, buffer = bufnr},
	d = {"<cmd>lua require'dap'.step_into()<CR>", "单步执行代码step_into()<F5>", mode = {'n', 'v'}, silent = true, noremap = true, buffer = bufnr},
	e = {"<cmd>lua require'dapui'.open({})<CR>", "打开调试窗口<F1>", mode = {'n', 'v'}, silent = true, noremap = true, buffer = bufnr},
	f = {"<cmd>lua require('dapui').close({})<CR>", "关闭调试窗口<ESC>", mode = {'n', 'v'}, silent = true, noremap = true, buffer = bufnr},
}
--设置断点
keymap({ "n", "v"}, "<F9>", "<cmd>lua require'dap'.toggle_breakpoint()<CR>", {silent = true, noremap = true, buffer = bufnr}) 
	--启动调试，断点继续
keymap({ "n", "v"}, "<F10>", "<cmd>lua require'dap'.continue()<CR>", {silent = true, noremap = true, buffer = bufnr})
	--单步执行代码
keymap({ "n", "v"}, "<F4>", "<cmd>lua require'dap'.step_over()<CR>", {silent = true, noremap = true, buffer = bufnr})
keymap({ "n", "v"}, "<F5>", "<cmd>lua require'dap'.step_into()<CR>", {silent = true, noremap = true, buffer = bufnr})
--dap ui快捷键绑定
keymap({"n", "v"}, "<F1>", "<cmd>lua require'dapui'.open({})<CR>", {silent = true, noremap = true, buffer = bufnr})
keymap({"n"}, "<ESC>", "<cmd>lua require('dapui').close({})<CR>", {silent = true, noremap = true, buffer = bufnr})



-----------------------------------------悬浮终端快捷键绑定-----------------------------------------
-- t = terminalKM
terminalKM = {
	name = "悬浮终端｜",
	["0"] = {"<cmd>ToggleTerm direction=float<cr>", "打开悬浮终端<A-d>" },
	["1"] = {"<cmd>ToggleTerm size=40 direction=horizontal<cr>", "在底部打开终端" },
	["2"] = {"<cmd>ToggleTerm size=40 direction=tab<cr>", "打开全屏终端" },
	["3"] = {"<cmd>ToggleTerm size=40 direction=vertical<cr>", "在右侧方打开终端" },
	o = {"<cmd>ToggleTerm<cr>", "开｜关终端页面UI" },
	g =  {"<cmd>TermExec cmd='echo -en \"\\\\e[32;1m请输入项目名：\\\\e[0m\";read op;mkdir \\$op&&cd \\$op&&gradle init' dir=~/<cr>", "创建gradle项目｜" },
	m =  {"<cmd>TermExec cmd='echo -en \"\\\\e[32;1m请输入项目名：\\\\e[0m\";read op;mkdir \\$op&&cd \\$op&&mvn archetype:generate' dir=~/<cr>", "创建maven项目｜" },
	p = {"<cmd>TermExec cmd='echo -en \"\\\\e[32;1m请输入项目名：\\\\e[0m\";read op;mkdir -p \\$op/src&&cd \\$op&&touch src/a.php&&export PATH=\\$PATH:\\$HOME/.local/share/nvim/mason/packages/psalm/vendor/bin/&&psalm --init src 3&&psalm' dir=~/<cr>", "创建PHP项目｜" },
}
keymap({"i","n"}, "<A-d>", "<cmd>ToggleTerm size=40 direction=float<cr><CR>")


-----------------------------------------themes主题快捷键绑定-----------------------------------------
-- x = Themes
ThemesKM = {
	name = "主题｜状态栏",
	["0"] = {
		name = "tokyonight主题",
		--tokyonight可选tokyonight tokyonight-night tokyonight-storm tokyonight-day tokyonight-moon
		["0"] = {"<cmd>lua require('plugins/Beautify').tokyonight('tokyonight',true)<CR>", "tokyonight"},
		["1"] = {"<cmd>lua require('plugins/Beautify').tokyonight('tokyonight-night',true)<CR>", "night"},
		["2"] = {"<cmd>lua require('plugins/Beautify').tokyonight('tokyonight-storm',true)<CR>", "storm"},
		["3"] = {"<cmd>lua require('plugins/Beautify').tokyonight('tokyonight-day',true)<CR>", "day"},
		["4"] = {"<cmd>lua require('plugins/Beautify').tokyonight('tokyonight-moon',true)<CR>", "moon"},
	},
	["1"] = {
		name = "onedark主题",
		--"选择主题。可选dark, darker, cool, deep, warm, warmer, light
		["0"] = {"<cmd>lua require('plugins/Beautify').onedark('dark',true)<CR>", "dark"},
		["1"] = {"<cmd>lua require('plugins/Beautify').onedark('darker',true)<CR>", "darker"},
		["2"] = {"<cmd>lua require('plugins/Beautify').onedark('cool',true)<CR>", "cool"},
		["3"] = {"<cmd>lua require('plugins/Beautify').onedark('deep',true)<CR>", "deep"},
		["4"] = {"<cmd>lua require('plugins/Beautify').onedark('warm',true)<CR>", "warm"},
		["5"] = {"<cmd>lua require('plugins/Beautify').onedark('warmer',true)<CR>", "warmer"},
		["6"] = {"<cmd>lua require('plugins/Beautify').onedark('light',true)<CR>", "light"},
	},
	["2"] = {
		name = "gruvbox主题",
		--"选择主题。可选light dark
		["0"] = {"<cmd>lua require('plugins/Beautify').gruvbox('light',true)<CR>", "light"},
		["1"] = {"<cmd>lua require('plugins/Beautify').gruvbox('dark',true)<CR>", "dark"},
	},
	["3"] = {
		name = "vim-colors-solarized主题",
		--"选择主题。可选light dark
		["0"] = {"<cmd>lua require('plugins/Beautify').vim_colors_solarized('light',true)<CR>", "light"},
		["1"] = {"<cmd>lua require('plugins/Beautify').vim_colors_solarized('dark',true)<CR>", "dark"},
	},
	["4"] = {
		name = "vim-atom-dark主题",
		--"选择主题。可选light dark
		["0"] = {"<cmd>lua require('plugins/Beautify').vim_atom_dark('atom-dark',true)<CR>", "atom-dark"},
		["1"] = {"<cmd>lua require('plugins/Beautify').vim_atom_dark('atom-dark-256',true)<CR>", "atom-dark-256"},
	},
	["5"] = {
		name = "papercolor-theme主题",
		--"选择主题。可选light dark
		["0"] = {"<cmd>lua require('plugins/Beautify').papercolor_theme('dark',true)<CR>", "dark"},
		["1"] = {"<cmd>lua require('plugins/Beautify').papercolor_theme('light',true)<CR>", "light"},
	},
	["6"] = {
		name = "nord-vim主题",
		["0"] = {"<cmd>lua require('plugins/Beautify').nord_vim('nord',true)<CR>", "nord-vim"},
	},
	["7"] = {
		name = "vim-one主题",
		--"选择主题。可选light dark
		["0"] = {"<cmd>lua require('plugins/Beautify').vim_one('dark',true)<CR>", "dark"},
		["1"] = {"<cmd>lua require('plugins/Beautify').vim_one('light',true)<CR>", "light"},
	},
	["8"] = {
		name = "purify主题",
		--"选择主题。可选light dark
		["0"] = {"<cmd>lua require('plugins/Beautify').purify('dark',true)<CR>", "dark"},
		["1"] = {"<cmd>lua require('plugins/Beautify').purify('brown',true)<CR>", "brown"},
	},
	["9"] = {
		name = "lualine状态栏",
		--"可选
		["0"] = {"<cmd>lua require('plugins/Beautify').lualine('auto',true)<CR>", "auto"},
		["1"] = {"<cmd>lua require('plugins/Beautify').lualine('16color',true)<CR>", "16color"},
		["2"] = {"<cmd>lua require('plugins/Beautify').lualine('ayu_dark',true)<CR>", "ayu_dark"},
		["3"] = {"<cmd>lua require('plugins/Beautify').lualine('ayu_light',true)<CR>", "ayu_light"},
		["4"] = {"<cmd>lua require('plugins/Beautify').lualine('ayu_mirage',true)<CR>", "ayu_mirage"},
		["5"] = {"<cmd>lua require('plugins/Beautify').lualine('ayu',true)<CR>", "ayu"},
		["6"] = {"<cmd>lua require('plugins/Beautify').lualine('base16',true)<CR>", "base16"},
		["7"] = {"<cmd>lua require('plugins/Beautify').lualine('codedark',true)<CR>", "codedark"},
		["8"] = {"<cmd>lua require('plugins/Beautify').lualine('dracula',true)<CR>", "dracula"},
		["9"] = {"<cmd>lua require('plugins/Beautify').lualine('everforest',true)<CR>", "everforest"},
		["a"] = {"<cmd>lua require('plugins/Beautify').lualine('gruvbox_dark',true)<CR>", "gruvbox_dark"},
		["b"] = {"<cmd>lua require('plugins/Beautify').lualine('gruvbox_light',true)<CR>", "gruvbox_light"},
		["c"] = {"<cmd>lua require('plugins/Beautify').lualine('gruvbox',true)<CR>", "gruvbox"},
		["d"] = {"<cmd>lua require('plugins/Beautify').lualine('gruvbox-material',true)<CR>", "gruvbox-material"},
		["e"] = {"<cmd>lua require('plugins/Beautify').lualine('horizon',true)<CR>", "horizon"},
		["f"] = {"<cmd>lua require('plugins/Beautify').lualine('iceberg_dark',true)<CR>", "iceberg_dark"},
		["g"] = {"<cmd>lua require('plugins/Beautify').lualine('iceberg_light',true)<CR>", "iceberg_light"},
		["h"] = {"<cmd>lua require('plugins/Beautify').lualine('iceberg',true)<CR>", "iceberg"},
		["i"] = {"<cmd>lua require('plugins/Beautify').lualine('jellybeans',true)<CR>", "jellybeans"},
		["j"] = {"<cmd>lua require('plugins/Beautify').lualine('material',true)<CR>", "material"},
		["k"] = {"<cmd>lua require('plugins/Beautify').lualine('modus-vivendi',true)<CR>", "modus-vivendi"},
		["l"] = {"<cmd>lua require('plugins/Beautify').lualine('molokai',true)<CR>", "molokai"},
		["m"] = {"<cmd>lua require('plugins/Beautify').lualine('moonfly',true)<CR>", "moonfly"},
		["n"] = {"<cmd>lua require('plugins/Beautify').lualine('nightfly',true)<CR>", "nightfly"},
		["o"] = {"<cmd>lua require('plugins/Beautify').lualine('nord',true)<CR>", "nord"},
		["p"] = {"<cmd>lua require('plugins/Beautify').lualine('OceanicNext',true)<CR>", "OceanicNext"},
		["q"] = {"<cmd>lua require('plugins/Beautify').lualine('onedark',true)<CR>", "onedark"},
		["r"] = {"<cmd>lua require('plugins/Beautify').lualine('onelight',true)<CR>", "onelight"},
		["s"] = {"<cmd>lua require('plugins/Beautify').lualine('palenight',true)<CR>", "palenight"},
		["t"] = {"<cmd>lua require('plugins/Beautify').lualine('papercolor_dark',true)<CR>", "papercolor_dark"},
		["u"] = {"<cmd>lua require('plugins/Beautify').lualine('papercolor_light',true)<CR>", "papercolor_light"},
		["v"] = {"<cmd>lua require('plugins/Beautify').lualine('PaperColor',true)<CR>", "PaperColor"},
		["w"] = {"<cmd>lua require('plugins/Beautify').lualine('powerline',true)<CR>", "powerline"},
		["x"] = {"<cmd>lua require('plugins/Beautify').lualine('powerline_dark',true)<CR>", "powerline_dark"},
		["y"] = {"<cmd>lua require('plugins/Beautify').lualine('pywal',true)<CR>", "pywal"},
		["z"] = {"<cmd>lua require('plugins/Beautify').lualine('seoul256',true)<CR>", "seoul256"},
		["A"] = {"<cmd>lua require('plugins/Beautify').lualine('solarized_dark',true)<CR>", "solarized_dark"},
		["B"] = {"<cmd>lua require('plugins/Beautify').lualine('solarized_light',true)<CR>", "solarized_light"},
		["C"] = {"<cmd>lua require('plugins/Beautify').lualine('Tomorrow',true)<CR>", "Tomorrow"},
		["D"] = {"<cmd>lua require('plugins/Beautify').lualine('wombat',true)<CR>", "wombat"},
	},
}

-----------------------------------------Packer包插件管理快捷键绑定-----------------------------------------
packerKM = {
	name = "Nvim插件管理［Packer］",
	a = {"<cmd>PackerUpdate<CR>", "更新插件", mode = {'n'}, silent = true, noremap = true, buffer = bufnr},
	b = {"<cmd>PackerSync<CR>", "同步插件状态", mode = {'n'}, silent = true, noremap = true, buffer = bufnr},
	c = {"<cmd>PackerClean<CR>", "清除无用插件", mode = {'n'}, silent = true, noremap = true, buffer = bufnr},
	d = {"<cmd>PackerStatus<CR>", "显示已安装插件的列表", mode = {'n'}, silent = true, noremap = true, buffer = bufnr},
}


-----------------------------------------tree文档树快捷键绑定-----------------------------------------
keymap("n", "<leader>e", ":NvimTreeToggle<CR>")  -- 主键+e开启



-----------------------------------------Mason服务器管理插件快捷键绑定-----------------------------------------
masonKM = {
	name = "Lsp和Dap管理［Mason］",
	a = {"<cmd>Mason<CR>", "Mason服务器管理", mode = {'n'}, silent = true, noremap = true, buffer = bufnr},
}


-----------------------------------------Null-ls代码格式化快捷键绑定-----------------------------------------
--保存文件时，自动格式化代码并保存
--并且在lsp服务器，注册vim.api.nvim_set_keymap('n', '<leader>f', '<cmd>lua vim.lsp.buf.format{async = true}<CR>', opts)
vim.cmd [[
	" 代码自动格式化
	augroup _auto_format
		autocmd!
		autocmd BufWritePre <buffer> :lua vim.lsp.buf.format()
	augroup end
]]


-----------------------------------------telescope查找器快捷键绑定-----------------------------------------
-- 进入telescope页面会是插入模式，回到正常模式就可以用j和k来移动了
--telescope.nvim大概有上几十种方法提供！请去官网添加需要的功能！
local builtin = require('telescope.builtin')
--当快捷键绑定相同时，仅需要给它起个名字即可
telescopeKM = {
	name = "查找｜搜索",
	f = {"查找文件"},
	g = {"模糊搜索"},
	b = {"搜索当前文件"},
	h = {"帮助"},
}
keymap('n', '<leader>ff', builtin.find_files, {})
keymap('n', '<leader>fg', builtin.live_grep, {})  -- 环境里要安装ripgrep
keymap('n', '<leader>fb', builtin.buffers, {})
keymap('n', '<leader>fh', builtin.help_tags, {})


-----------------------------------------Lspsaga lsp轻量级插件快捷键绑定-----------------------------------------
-- :Lspsaga lsp_finder
	-- 表示定义、引用和实现（仅当当前悬停的单词是函数、类型、类或接口时才显示）。
-- :Lspsaga peek_definition
	-- 有两个命令，和 。该命令的工作方式类似于同名的 VSCode 命令，后者在可编辑的浮动窗口中显示目标文件。:Lspsaga peek_definition  :Lspsaga goto_definitionpeek_definition
	-- 作用，例如：快速定位函数并修改
-- :Lspsaga goto_definition
	-- 跳转到悬停单词的定义，并显示信标突出显示。(不需要配置)
-- :Lspsaga code_action
	-- num_shortcut 这是默认的，因此您可以通过按其相应的数字来快速运行代码操作。true
-- :Lspsaga Lightbulb
	-- 当有可能要执行代码操作时，将显示一个灯泡图标。
-- :Lspasga hover_doc
	-- 您应该安装 treeitter markdown 解析器，以便 Lspsaga 可以使用它来呈现悬停窗口。 您可以按两次键盘快捷键进入悬停窗口。
	-- 快速查看函数，变量的说明文档
-- :Lspsaga diagnostic_jump_next
	-- 跳转到下一个诊断位置并显示信标突出显示。然后，Lspsaga 将显示代码操作。
-- :Lspsaga show_diagnostics
	-- 可以使用跳转到和使用跳转到诊断位置<C-w>w<CR>
-- :Lspsaga rename
	-- 使用当前 LSP 重命名悬停的单词。
-- :Lspsaga outline
	-- 显示代码文件大纲
-- :Lspsaga incoming_calls
	-- 运行 LSP 的呼叫层次结构/incoming_calls。
-- :Lspsaga outgoing_calls
	-- 运行 LSP 的呼叫层次结构/outgoing_calls。
-- :Lspsaga symbols in winbar
	-- 文柱中的Lspsaga符号
-- :Lspsaga term_toggle
	-- 一个简单的浮动终端。
	-- 打开后，Ctrl + d 关闭
-- :Lspsaga beacon
	-- 从浮动窗口跳转后，将显示信标以提醒您光标的位置.
-- :Lspsaga UI
	-- 默认 UI 选项

-- g = lspsagaKM
lspsagaKM = {
    name = "Lsp插件功能｜",
    a = {"提供可用的代码操作codeAction"},
    d = {
        name = "定位修改类｜方法｜函数｜接口",
        a = {"以悬浮窗口方式"},
        b = {"以快速定位方式"},
    },
    e = {"下一个诊断位置｜黄色标记"},
    E = {"上一个诊断位置｜黄色标记"},
    h = {"显示类｜方法｜函数｜接口信息"},
    I = {"LSP呼叫层次｜incoming_calls"},
    k = {"快速查看函数，变量的说明文档"},
    K = {"快速查看函数，变量的说明文档++keep"},
    o = {"代码文件大纲"},
    O = {"LSP呼叫层次｜outgoing_calls"},
    r = {"重命名单词"},
    R = {"重命名单词 ++project"},
--    t = {"悬浮终端<Alt-d>"},
    
}
keymap("n", "<leader>lla", "<cmd>Lspsaga code_action<CR>")
keymap("n", "<leader>llh", "<cmd>Lspsaga lsp_finder<CR>")
keymap("n", "<leader>llda", "<cmd>Lspsaga peek_definition<CR>")
keymap("n","<leader>lldb", "<cmd>Lspsaga goto_definition<CR>")
keymap("n", "<leader>llk", "<cmd>Lspsaga hover_doc<CR>")
keymap("n", "<leader>llK", "<cmd>Lspsaga hover_doc ++keep<CR>")
keymap("n", "<leader>llE", "<cmd>Lspsaga diagnostic_jump_prev<CR>")
keymap("n", "<leader>lle", "<cmd>Lspsaga diagnostic_jump_next<CR>")
--有diagnostic_jump诊断就够用了
--keymap("n", "<leader>sl", "<cmd>Lspsaga show_line_diagnostics<CR>")
--keymap("n", "<leader>sc", "<cmd>Lspsaga show_cursor_diagnostics<CR>")
--keymap("n", "<leader>sb", "<cmd>Lspsaga show_buf_diagnostics<CR>")
keymap("n", "<leader>llr", "<cmd>Lspsaga rename<CR>")
keymap("n", "<leader>llR", "<cmd>Lspsaga rename ++project<CR>")
keymap("n","<leader>llo", "<cmd>Lspsaga outline<CR>")
keymap("n", "<Leader>llI", "<cmd>Lspsaga incoming_calls<CR>")
keymap("n", "<Leader>llO", "<cmd>Lspsaga outgoing_calls<CR>")
keymap({"n"}, "<Leader>llt", "<cmd>Lspsaga term_toggle<CR>")
--keymap({"n"}, "<A-d>", "<cmd>Lspsaga term_toggle<CR>")
-- Diagnostic jump with filters such as only jumping to an error
keymap("n", "[E", function()
	require("lspsaga.diagnostic"):goto_prev({ severity = vim.diagnostic.severity.ERROR })
end)
keymap("n", "]E", function()
	require("lspsaga.diagnostic"):goto_next({ severity = vim.diagnostic.severity.ERROR })
end)



-----------------------------------------comment注释快捷键绑定-----------------------------------------
commentKM = {
    name = "注释",
    c = {"单行注释｜取消"},
    C = {"多行注释｜取消"},
}
lspsagaKM = utils.addKM(lspsagaKM, commentKM)


-----------------------------------------Marks简单行标记快捷键绑定-----------------------------------------
marksKM = {
	name = "行标记｜快捷键",
	["0"] = { "标记"},
	["1"] = { "标记"},
	["2"] = { "标记⚑"},
	["3"] = { "标记"},
	["4"] = { "标记"},
	["5"] = { "标记"},
	["6"] = { "标记"},
	["7"] = { "标记"},
	["8"] = { "标记"},
	["9"] = { "标记"},
	d = {
		name = "删除标记",
		["0"] = { "删除全部"},
		["1"] = { "删除全部"},
		["2"] = { "删除全部⚑"},
		["3"] = { "删除全部"},
		["4"] = { "删除全部"},
		["5"] = { "删除全部"},
		["6"] = { "删除全部"},
		["7"] = { "删除全部"},
		["8"] = { "删除全部"},
		["9"] = { "删除全部"},
		d = { "删除当前行标记"},
	},
	["+"] = { "<cmd>lua require'marks'.prev_bookmark()<CR>","跳到上一个同类型的标记点"},
	["-"] = { "<cmd>lua require'marks'.next_bookmark()<CR>","跳到下一个同类型的标记点" },
}

for i = 0,9 do
	keymap("n", "<leader>m"..i, "<cmd>lua require'marks'.set_bookmark"..i.."()<CR>")
	keymap("n", "<leader>md"..i, "<cmd>lua require'marks'.delete_bookmark"..i.."()<CR>")
end
keymap("n", "<leader>mdd", "<cmd>lua require'marks'.delete_bookmark()<CR>")


-----------------------------------------代码折叠快捷键绑定-----------------------------------------
--" 代码折叠 zc折叠 zo展开 zM一次性折叠 zR一次性全部展开
zdKM = {
	name = "代码折叠｜缩进线--",
	c = {"<leader>zc<cr>", "折叠一次<F2>"},
	o = {"<leader>zo<cr>", "展开一次<F3>"},
	M = {"<leader>zM<cr>", "折叠全部<C-r>"},
	R = {"<leader>zR<cr>", "展开全部<C-R>"},
	a = {"<cmd>:IndentLinesToggle<cr>", "打开｜关闭缩进线--"},
}
keymap({ "i", "n"}, "<F2>", "<ESC>zc <CR><ESC>i")
keymap({"i", "n"}, "<F3>", "<ESC>zo <CR><ESC>i")
keymap({"i", "n"}, "<C-p>", "<ESC>zM <CR><ESC>i")
keymap({"i", "n"}, "<C-r>", "<ESC>zR <CR><ESC>i")
vim.cmd[[
" 自动关闭首页的缩进线
autocmd FileType dashboard :IndentLinesToggle
" 自动关闭文档树的缩进线
autocmd FileType nvim-tree :IndentLinesToggle
" 自动关闭Mason.nvim的缩进线
autocmd FileType mason :IndentLinesToggle
" 自动关闭Packer的缩进线
autocmd FileType packer :IndentLinesToggle
" 自动关闭显示动物的缩进线
autocmd FileType pets :IndentLinesToggle
]]



-----------------------------------------Trans翻译快捷键-----------------------------------------
TransKM = {
	name = "单词翻译｜",
	o = {'<Cmd>Translate<CR>', "翻译光标所在单词<C-o>"},
	s = {'<Cmd>TranslateInput<CR>', "查找单词<C-f>"},
	y = {"单词发音｜未编译，功能暂时无法使用"},
}
vim.keymap.set({'n', 'i'}, '<C-o>', '<Cmd>Translate<CR>')
--vim.keymap.set({'n', 'i'}, '<leader>o', '<Cmd>TransPlay<CR>') -- 自动发音选中或者光标下的单词
vim.keymap.set({'n', 'i'}, '<C-f>', '<Cmd>TranslateInput<CR>')

-----------------------------------------数据库MySQL快捷键-----------------------------------------
-- b = mysqlKM,
mysqlKM = {
	name = "数据库｜",
	a = {'<Cmd>:DBUIAddConnection<CR>', "添加数据库Url"},
	x = {'<Cmd>:w<CR>', "执行sql语句<F6>"},
	m = {'<Cmd>:DBUIToggle<CR>', "开｜关数据库视图<A-m>"},
	--w = {'<Cmd>@<Plug>(DBUI_SaveQuery)<CR>', "保存查询结果"},
}
vim.keymap.set({'n', 'i'}, "<A-m>", '<ESC><Cmd>:DBUIToggle<CR>')
vim.keymap.set({'n', 'i'}, '<F6>', '<ESC><Cmd>:w<CR>')
vim.cmd[[
nmap <C-W> <Plug>(DBUI_SaveQuery)
autocmd FileType dbui nmap <buffer> v <Plug>(DBUI_SelectLineVsplit)
autocmd FileType dbui nmap <cr> <Plug>(DBUI_SelectLine)
set cursorline
]]



-----------------------------------------常用快捷键区-----------------------------------------
markdownKM = {
	name = "markdown预览",
	p = {'<Cmd>:MarkdownPreview<CR>', "打开markdown预览<C-p>"},
	s = {'<Cmd>:MarkdownPreviewStop<CR>', "关闭markdown预览<A-p>"},
}
vim.cmd[[
" 映射
nmap <A-s> <Plug>MarkdownPreviewStop
nmap <C-p> <Plug>MarkdownPreview
" nmap <C-p> <Plug>MarkdownPreviewToggle
]]
-----------------------------------------功能区快捷键-----------------------------------------
--a = toolKM,
toolKM = {
	name = "工具｜功能区",
	s = { "分享当前文件到QQ｜微信"},
	c = { "用其他应用打开当前文件"},
	b = { "待开发"},
	
}
vim.keymap.set({'n'}, '<leader>as', "<cmd>:w!<cr><cmd>lua io.popen('termux-share '..vim.api.nvim_buf_get_name(0))<cr>")
vim.keymap.set({'n'}, '<leader>as', "<cmd>:w!<cr><cmd>lua io.popen('termux-open '..vim.api.nvim_buf_get_name(0))<cr>")

-----------------------------------------帮助文档快捷键-----------------------------------------
--h = helpKM
helpKM = {
	name = "帮助文档｜",
	a = {"<cmd>lua require'plugins/utils'.funMarksLog(1)<cr>", "标记行-说明文档"},
	b = {"<cmd>lua require'plugins/utils'.funMarksLog(2)<cr>", "常用快捷键-说明文档"},
	c = {"<cmd>lua require'plugins/utils'.funMarksLog(3)<CR>", "Dap帮助文档", mode = {'n', 'v'}, silent = true, noremap = true, buffer = bufnr},
	d = {"<cmd>lua require'plugins/utils'.funMarksLog(4)<CR>", "Lsp帮助文档"},
	e = {"<cmd>lua require'plugins/utils'.funMarksLog(5)<cr>", "SQL说明文档"},

}

