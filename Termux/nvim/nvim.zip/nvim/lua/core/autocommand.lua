--自动执行nvim命令
--[[
1、autocommand通用格式
	augroup _auto_format
		autocmd!
		autocmd cpp,java event command （核心，其他都是固定）
	augroup end
	
解释：autocmd 过滤的文件类型 监听的事件 执行的命令
--]]


--在lua里面使用vim的命令
vim.cmd [[
	augroup _general_settings
		autocmd!
		autocmd FileType qf,help,man,lspinfo nnoremap <silent> <buffer> q :close<CR> 
		autocmd TextYankPost * silent!lua require('vim.highlight').on_yank({higroup = 'Search', timeout = 200}) 
		autocmd BufWinEnter * set formatoptions-=cro
	augroup end
	
	augroup _git
		autocmd!
		autocmd FileType gitcommit setlocal wrap
		autocmd FileType gitcommit setlocal spell
	augroup end
	
	augroup _markdown
		autocmd!
		autocmd FileType markdown setlocal wrap
		autocmd FileType markdown setlocal spell
	augroup end
	
	" augroup _auto_resize
	"	 autocmd!
	"	 autocmd VimResized * tabdo wincmd = 
	" augroup end
	
	augroup _alpha
		autocmd!
		autocmd User AlphaReady set showtabline=0 | autocmd BufUnload <buffer> set showtabline=2
	augroup end

	" 代码自动格式化
	"augroup _auto_format
	"	autocmd!
	"	autocmd BufWritePre <buffer> :lua vim.lsp.buf.formatting_sync()
	"augroup end

	" 代码折叠 zc折叠 zo展开 zM一次性折叠 zR一次性全部展开
	augroup _fold_bug_solution	" https://github.com/nvim-telescope/telescope.nvim/issues/559
		autocmd!
		autocmd BufRead * autocmd BufWinEnter * ++once normal! zx
	augroup end
	
"	augroup _load_break_points
"		autocmd!
"		autocmd FileType c,cpp,go,python,lua :lua require('user.dap.dap-util').load_breakpoints()
"	augroup end

	augroup jdtls_lsp "自动启动 Lsp
		autocmd!
		autocmd FileType java :lua require'lsp/java'.setup()
	augroup end

]]
