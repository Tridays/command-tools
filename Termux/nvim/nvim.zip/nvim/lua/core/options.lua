
--vim.opt.xx选项设置
local options = {
	-- 行号
	relativenumber = true,
	number = true,
	-- 缩进
	tabstop = 4,
	shiftwidth = 4,
	expandtab = true,
	autoindent = true,
	-- 防止包裹
	wrap = false,
	-- 光标行
	cursorline = true,
	-- 默认新窗口右和下
	splitright = true,
	splitbelow = true,
	-- 搜索
	ignorecase = true, -- 搜索不区分大小写
	smartcase = true,
	-- 外观，终端真颜色
	termguicolors = true,
	signcolumn = "yes",
	
	backup = false,                          -- creates a backup file
	clipboard = "unnamedplus",               -- allows neovim to access the system clipboard
	cmdheight = 1,                           -- keep status bar position close to bottom
	completeopt = { "menuone", "noselect" }, -- mostly just for cmp
	conceallevel = 0,                        -- so that `` is visible in markdown files
	fileencoding = "utf-8",                  -- the encoding written to a file
	hlsearch = true,                         -- highlight all matches on previous search pattern
	mouse = "a",                             -- allow the mouse to be used in neovim
	pumheight = 10,                          -- pop up menu height
	showmode = false,                        -- we don't need to see things like -- INSERT -- anymore
	showtabline = 2,                         -- always show tabs
	smartindent = true,                      -- make indenting smarter again
	swapfile = false,                        -- creates a swapfile
	timeoutlen = 500,                        -- time to wait for a mapped sequence to complete (in milliseconds)
	undofile = true,                         -- enable persistent undo
	updatetime = 300,                        -- faster completion (4000ms default)
	writebackup = false,                     -- if a file is being edited by another program (or was written to file while editing with another program), it is not allowed to be edited
	cursorcolumn = false,                    -- 垂直光标坚线
	numberwidth = 4,                         -- set number column width to 2 {default 4}
	scrolloff = 8,                           -- keep 8 height offset from above and bottom
	sidescrolloff = 8,                       -- keep 8 width offset from left and right
	guifont = "monospace:h17",               -- the font used in graphical neovim applications

	foldmethod = "expr",                     -- fold with nvim_treesitter
	foldexpr = "nvim_treesitter#foldexpr()",
	foldenable = false,                      -- no fold to be applied when open a file
	foldlevel = 99,                          -- if not set this, fold will be everywhere
	spell = false,                            -- add spell support
	spelllang = { 'en_us' },                 -- support which languages?
	diffopt="vertical,filler,internal,context:4",                      -- vertical diff split view
	cscopequickfix="s-,c-,d-,i-,t-,e-",       -- cscope output to quickfix window
}

-- 启用鼠标
vim.opt.mouse:append("a")
-- 系统剪贴板
vim.opt.clipboard:append("unnamedplus")
--用于控制信息显示的种类和详细程度
vim.opt.shortmess:append "c"

for k, v in pairs(options) do
  vim.opt[k] = v
end
vim.cmd[[
set t_Co=256
]]





