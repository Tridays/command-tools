local dap = require('dap')
--java调试器（server版）
dap.adapters.java = function(callback, config)
	--启动vscode-debug 并返回一个连接端口
    require('jdtls.util').execute_command({command = 'vscode.java.startDebugSession'},
     function(err0, port)
     print("127.0.0.1:"..vim.inspect(port))
      assert(not err0, vim.inspect(err0))
      callback({
      type = 'server';
      host = '127.0.0.1';
      port = port;
       })      
    end)
end

--java配置文件（可以设置不同的命令）（也可以由lsp自动提供调试器配置）
dap.configurations.java = {
  {
    type = 'java',-->指的是选择哪个配适器
    request = 'launch',
    name = "Java Debug(attach)",
    hostName = "127.0.0.1",
    port = 5005,
    --jar包依赖包的路径
    classPaths = {"${fileDirname}"},
    --Java文件所在的路径
    mainClass = "${file}",
    --projectName = "",
    javaExec = "java",
    --modulePath = "",
    
  }
}


-----------------------------Python-----------------------------
dap.adapters.python = {
  type = 'executable';
  command = 'python';
  args = { '-m', 'debugpy.adapter' };
}

dap.configurations.python = {
  {
    -- The first three options are required by nvim-dap
    type = 'python'; -- the type here established the link to the adapter definition: `dap.adapters.python`
    request = 'launch';
    name = "Python Debug(launch)";

    -- Options below are for debugpy, see https://github.com/microsoft/debugpy/wiki/Debug-configuration-settings for supported options

    program = "${file}"; -- This configuration will launch the current file if used.
    pythonPath = "python";
--[[    pythonPath = function()
      -- debugpy supports launching an application with a different interpreter then the one used to launch debugpy itself.
      -- The code below looks for a `venv` or `.venv` folder in the current directly and uses the python within.
      -- You could adapt this - to for example use the `VIRTUAL_ENV` environment variable.
      local cwd = vim.fn.getcwd()
      if vim.fn.executable(cwd .. '/venv/bin/python') == 1 then
        return cwd .. '/venv/bin/python'
      elseif vim.fn.executable(cwd .. '/.venv/bin/python') == 1 then
        return cwd .. '/.venv/bin/python'
      else
        return '/usr/bin/python'
      end
    end;

--]]
  },
}













--有关C/C++/Rush暂时不可用
-----------------------------cpp-----------------------------
--[[
dap.adapters.cppdbg = { 
    id = "cppdbg",
    type = 'executable',
    command = os.getenv("HOME").."/.local/share/nvim/mason/packages/cpptools/extension/debugAdapters/bin/OpenDebugAD7",
}




dap.configurations.cpp = {
  {
    name = "cppdbg Debug(launch)",
    type = "cppdbg",
    request = "launch",
    program = function()
      return vim.fn.input('Path to executable: ', vim.fn.getcwd() .. '/', 'file')
    end,
    cwd = '${workspaceFolder}',
    stopAtEntry = true,
setupCommands = {
  { 
     text = '-enable-pretty-printing',
     description =  'enable pretty printing',
     ignoreFailures = false 
  },
},

  },
  {
    name = 'Attach to gdbserver :1234',
    type = 'cppdbg',
    request = 'launch',
    MIMode = 'gdb',
    miDebuggerServerAddress = 'localhost:1234',
    miDebuggerPath = 'gdb',
    cwd = '${workspaceFolder}',
    program = function()
      return vim.fn.input('Path to executable: ', vim.fn.getcwd() .. '/', 'file')
    end,
setupCommands = {
  { 
     text = '-enable-pretty-printing',
     description =  'enable pretty printing',
     ignoreFailures = false 
  },
},

  },
}
-----------------------------C同cpp-----------------------------
dap.configurations.c = dap.configurations.cpp
dap.configurations.Rush = dap.configurations.cpp








dap.adapters.lldb = {
  type = 'executable',
  command = 'lldb', -- adjust as needed, must be absolute path
  name = 'lldb'
}

dap.configurations.cpp = {
  {
    name = 'Launch',
    type = 'lldb',
    request = 'launch',
    program = function()
      return vim.fn.input('Path to executable: ', vim.fn.getcwd() .. '/', 'file')
    end,
    cwd = '${workspaceFolder}',
    stopOnEntry = false,
    args = {},

    -- ?
    -- if you change `runInTerminal` to true, you might need to change the yama/ptrace_scope setting:
    --
    --    echo 0 | sudo tee /proc/sys/kernel/yama/ptrace_scope
    --
    -- Otherwise you might get the following error:
    --
    --    Error on launch: Failed to attach to the target process
    --
    -- But you should be aware of the implications:
    -- https://www.kernel.org/doc/html/latest/admin-guide/LSM/Yama.html
    -- runInTerminal = false,
      env = function()
    local variables = {}
    for k, v in pairs(vim.fn.environ()) do
      table.insert(variables, string.format("%s=%s", k, v))
    end
    return variables
  end,

  },
}
--]]

dap.adapters.cppdbg = {
	--启动vscode-debug 并返回一个连接端口
      type = 'server';
      host = '127.0.0.1';
      port = 4711;
      --'/root/cpptools/extension/debugAdapters/bin/nvim-dap.ad7Engine.json'.
}









dap.configurations.cpp = {
  {
    name = "Launch file",
    type = "cppdbg",
    request = "launch",
    program = function()
      return vim.fn.input('Path to executable: ', vim.fn.getcwd() .. '/', 'file')
    end,
    cwd = '${workspaceFolder}',
    hostName = "127.0.0.1",
   -- miDebuggerServerAddress = 'localhost:1234',
   -- miDebuggerPath = '/bin/gdb',
    --port = 8100,
    stopAtEntry = true,
  },
  {
    name = 'Attach to gdbserver :1234',
    type = 'cppdbg',
    request = 'launch',
    MIMode = 'gdb',
    miDebuggerServerAddress = 'localhost:1234',
    miDebuggerPath = 'gdb',
    cwd = '${workspaceFolder}',
    program = function()
      return vim.fn.input('Path to executable: ', vim.fn.getcwd() .. '/', 'file')
    end,
  },
}






-- If you want to use this for Rust and C, add something like this:

dap.configurations.c = dap.configurations.cpp
dap.configurations.rust = dap.configurations.cpp



-----------------------------bash dap-----------------------------
dap.adapters.bashdb = {
  type = 'executable';
  command = vim.fn.stdpath("data") .. '/mason/packages/bash-debug-adapter/bash-debug-adapter';
  name = 'bashdb';
}
dap.configurations.sh = {
  {
    type = 'bashdb';
    request = 'launch';
    name = "Launch file";
    showDebugOutput = true;
    pathBashdb = vim.fn.stdpath("data") .. '/mason/packages/bash-debug-adapter/extension/bashdb_dir/bashdb';
    pathBashdbLib = vim.fn.stdpath("data") .. '/mason/packages/bash-debug-adapter/extension/bashdb_dir';
    trace = true;
    file = "${file}";
    program = "${file}";
    cwd = '${workspaceFolder}';
    pathCat = "cat";
    pathBash = "bash";
    pathMkfifo = "mkfifo";
    pathPkill = "pkill";
    args = {};
    env = {};
    terminalKind = "integrated";
  }
}

