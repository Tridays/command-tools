


local util = require 'lspconfig.util'
require'lspconfig'.zk.setup{
	cmd = { "zk", "lsp" },
	filetypes = { "markdown" },
	root_dir = util.root_pattern(".zk"),
}