

local util = require 'lspconfig.util'
require'lspconfig'.sqlls.setup{
	cmd = { "sql-language-server", "up", "--method", "stdio" },
	filetypes = { "sql", "mysql" },
    root_dir = util.root_pattern '.sqllsrc.json',
    settings = {},

}