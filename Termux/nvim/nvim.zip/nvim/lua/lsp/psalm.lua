local util = require 'lspconfig.util'

--php lsp服务器
--依赖命令 composer 
--[[
mkdir -p $HOME/MyPhpProject/src
touch $HOME/MyPhpProject/src/a.php
cd MyPhpProject
	运行初始化命令以创建配置文件psalm.xml：
	src是包含要分析的代码的目录，而3是设置级别。
	传递介于1和8之间的值。 1执行最严格的分析。 8是最宽松的。
psalm --init src 3
psalm 
nvim $HOME/MyPhpProject/src/a.php
--]]


if vim.fn.has 'win32' == 1 then
  bin_name = bin_name .. '.bat'
end


require'lspconfig'.psalm.setup{
  default_config = {
    cmd = {'psalm-language-server'},
    filetypes = { 'php' },
    root_dir = util.root_pattern('psalm.xml', 'psalm.xml.dist'),
  },
  docs = {
    description = [[
https://github.com/vimeo/psalm
Can be installed with composer.
```sh
composer global require vimeo/psalm
```
]],
    default_config = {
      cmd = {'psalm-language-server'},
      root_dir = [[root_pattern("psalm.xml", "psalm.xml.dist")]],
    },
  },
}