

local util = require 'lspconfig.util'
require'lspconfig'.sqls.setup{
	cmd = { "sqls" },
	filetypes = { "sql", "mysql" },
    root_dir = util.root_pattern 'config.yml',
    single_file_support = true,
    settings = {},
}