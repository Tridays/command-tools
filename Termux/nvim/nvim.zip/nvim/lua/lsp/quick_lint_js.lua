

local util = require 'lspconfig.util'
require'lspconfig'.quick_lint_js.setup{
	cmd = { "quick-lint-js", "--lsp-server" },
	filetypes = { "javascript" },
	root_dir = util.root_pattern('package.json', 'jsconfig.json', '.git'),
	single_file_support = true,
}




