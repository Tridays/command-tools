local util = require 'lspconfig.util'

--JavaScript
--[[
To configure typescript language server, add a tsconfig.json or jsconfig.json to the root of your project.
Here's an example that disables type checking in JavaScript files.

{
  "compilerOptions": {
    "module": "commonjs",
    "target": "es6",
    "checkJs": false
  },
  "exclude": [
    "node_modules"
  ]
}
--]]
require'lspconfig'.tsserver.setup{
	cmd = { "typescript-language-server", "--stdio" },
	filetypes = { "javascript", "javascriptreact", "javascript.jsx", "typescript", "typescriptreact", "typescript.tsx" },
	root_dir = util.root_pattern("package.json", "tsconfig.json", "jsconfig.json", ".git"),
	single_file_support = true,
	init_options = {
  hostInfo = "neovim"
},
}