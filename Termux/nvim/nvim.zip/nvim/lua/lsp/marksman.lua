

local util = require 'lspconfig.util'
require'lspconfig'.marksman.setup{
	cmd = { "marksman", "server" },
	filetypes = { "markdown" },
	root_dir = util.root_pattern(".git", ".marksman.toml"),
	single_file_support = true,
}