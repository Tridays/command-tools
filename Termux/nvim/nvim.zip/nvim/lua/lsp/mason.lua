--Mason lsp安装插件

require("mason").setup({
	ui = {
		icons = {
			package_installed = "✓",
			package_pending = "➜",
			package_uninstalled = "✗"
		}
	}
})



require("mason-lspconfig").setup({
	-- 确保lsp服务器安装，根据需要填写（nvim命令行输入 :Mason 即可自动安装）
	-- 或者 :LspInstall python 也可以下载对应Python的lsp服务器
	-- 查看有哪些可用lsq服务器https://github.com/neovim/nvim-lspconfig/blob/master/doc/server_configurations.md
	ensure_installed = {
		"jdtls",  --java
		"pyright",  --python
		--"clangd",    --C/C++  使用npm i -g clangd
		"bashls",  --bash  使用npm i -g bash-language-server
		"psalm",   --php
		"cssls",  --css  需要npm i -g vscode-langservers-extracted
		"gopls",  --go
		"gradle_ls",  --gradle
		"html",  --html
		"jsonls",  --json
		--"quick_lint_js",  --JavaScript
		"tsserver",  --JavaScript
		--"texlab",  --LaTex   使用pkg i texlab
		--"marksman",  --markdown 使用npm i -g marksman
		"sqls",  --SQL
		--"sqlls",  --SQL
		"zk",  --markdown
	},
})
