local M = {}
function M.setup()
	-- 获取HOME目录
	local home = os.getenv("HOME") .. "/"
	root_dir = require("jdtls.setup").find_root({ ".git", "mvnw", "gradlew", "pom.xml", "build.gradle" })
--[[



:lua = require("lsp/utils").get_current_package_name()
:lua = require("lsp/utils").get_current_class_name()

:lua require('jdtls.dap').setup_dap_main_class_configs()
:lua require("jdtls.dap").setup_dap_main_class_configs({ verbose = true })

:lua require('jdtls.dap').setup_dap_main_class_configs()
:JdtRefreshDebugConfigs

:lua require'jdtls'.test_nearest_method()

:lua require'jdtls'.test_nearest_method({ config = { console = 'console' }})
:lua = require'jdtls'.test_class()
:lua = require("jdtls").compile()
:lua = require("jdtls").organize_imports()
:lua = require("jdtls").extract_method()


:lua print(vim.inspect(require'dap'.adapters))
:lua print(vim.inspect(require'dap'.configurations.java))

:lua require'dapui'.setup({})
:lua require'dapui'.open()

:lua =vim.lsp.get_active_clients()


vscode.java.test.search.codelens
vscode.java.fetchUsageData 获取调试器默认配置。
vscode.java.startDebugSession 启动调试器的 TCP 服务，返回端口号。
vscode.java.resolveClasspath 获取被调试 Java 程序的类路径。
vscode.java.resolveMainClass 获取被调试 Java 程序的 main 方法所在类，与类路径一同用于初始化调试器配置，最终会在指定的链接器中调用 .launch 时作为参数。这个参数在 VSCODE 中也可以由用户指定。
vscode.java.buildWorkspace 在启动调试之前构建被调试程序。
vscode.java.updateDebugSettings 更新调试器设置。
调试器启动之前，会先向 LSP 服务发送 vscode.java.resolveClasspath、vscode.java.resolveMainClass、vscode.java.buildWorkspace 等请求来构建被调试程序并获取 mainClass、classPaths 等必要的参数。
之后客户端发送 vscode.java.startDebugSession 命令后会启动 TCPServer 等待客户端连接。
:lua require('jdtls.util').execute_command({command = 'vscode.java.startDebugSession'}, function(err0, port) print(vim.inspect(port)) end)
:lua = require('jdtls.util').execute_command({command = 'vscode.java.resolveMainClass'}, function(err0, mainclasses) print_r(mainclasses) end)
:lua = require('jdtls.util').execute_command({command = 'vscode.java.resolveClasspath'}, function(err0, mainclasses) print(mainclasses) end)
:lua printTable({require('jdtls.util').execute_command({command = 'vscode.java.test.findTestTypesAndMethods file:///data/data/com.termux/files/home/gra/app/src/main/java/com/example/hzt/App.java'}, function(err0, mainclasses) print(mainclasses) end)})



:lua require('jdtls.util').execute_command({command = 'vscode.java.resolveMainClass'}, function(err0, mainclasses) print_r(mainclasses) end)


:lua require('jdtls.util').execute_command({command = 'vscode.java.ShowDocumentClientCapabilities'}, function(err0, mainclasses) print(vim.inspect(mainclasses)) end)

通过 设置断点。:lua require'dap'.toggle_breakpoint()
通过 启动调试会话并恢复执行。:lua require'dap'.continue()
通过 和 单步执行代码。:lua require'dap'.step_over()
:lua require'dap'.step_into()
通过内置 REPL： 或使用小部件 UI 检查状态 :lua require'dap'.repl.open() :help dap-widgets
帮助 :help dap-mapping:help dap-api


--]]

	-- This bundles definition is the same as in the previous section (java-debug installation)
	local bundles = {
		vim.fn.glob(
			home
				.. ".local/share/nvim/mason/packages/java-debug-adapter/extension/server/com.microsoft.java.debug.plugin-*.jar"
		),
		--  vim.fn.glob("/data/data/com.termux/files/home/gra/*.jar"),
	}
	-- This is the new part
	vim.list_extend(
		bundles,
		vim.split(vim.fn.glob(home .. ".local/share/nvim/mason/packages/java-test/extension/server/*.jar"), "\n")
	)

	local on_attach = function(client, buffer)
		-- With `hotcodereplace = 'auto' the debug System.out.println();r will try to apply code changes
		-- you make during a debug session immediately.
		-- Remove the option if you do not want that.
		require("jdtls").setup_dap({ hotcodereplace = "auto" })
		require("jdtls.setup").add_commands()
		--require("kide.core.keybindings").maplsp(client, buffer)
		require("jdtls.dap").setup_dap_main_class_configs({ verbose = true })

		--  local opts = { silent = true, buffer = buffer }
		--  vim.keymap.set("n", "<leader>dc", jdtls.test_class, opts)
		--  vim.keymap.set("n", "<leader>dm", jdtls.test_nearest_method, opts)
		--  vim.keymap.set("n", "crv", jdtls.extract_variable, opts)
		--  vim.keymap.set("v", "crm", [[<ESC><CMD>lua require('jdtls').extract_method(true)<CR>]], opts)
		--  vim.keymap.set("n", "crc", jdtls.extract_constant, opts)
		--  local create_command = vim.api.nvim_buf_create_user_command
		--  create_command(buffer, "OR", require("jdtls").organize_imports, {
		--    nargs = 0,
		--  })
		--vim.api.nvim_buf_create_user_command(buffer, "OR", require("jdtls").organize_imports, {nargs = 0,})
		-- if vim.g.jdtls_dap_main_class_config_init then
		--   vim.defer_fn(function()
		--     require("jdtls.dap").setup_dap_main_class_configs({ verbose = true })
		--   end, 3000)
		--   vim.g.jdtls_dap_main_class_config_init = false
		-- end

		require("nvim-navic").attach(client, buffer)
		require("java-deps").attach(client, buffer, root_dir)
		create_command(buffer, "JavaProjects", require("java-deps").toggle_outline, {
			nargs = 0,
		})
		-- vim.notify(vim.api.nvim_buf_get_name(bufnr), vim.log.levels.INFO)
	end

	local capabilities = vim.lsp.protocol.make_client_capabilities()
	--local capabilities = require('cmp_nvim_lsp').default_capabilities(capabilities)  --会使代码片段错乱

	local extendedClientCapabilities = require("jdtls").extendedClientCapabilities
	extendedClientCapabilities.resolveAdditionalTextEditsSupport = true

	local config = {
		--autostart = true,

		--启动jdtls
		cmd = {
			"java",
			--    "-agentlib:jdwp=transport=dt_socket,server=y,suspend=y,address=127.0.0.1:5005 ",
			"-Declipse.application=org.eclipse.jdt.ls.core.id1",
			"-Dosgi.bundles.defaultStartLevel=4",
			"-Declipse.product=org.eclipse.jdt.ls.core.product",
			"-Dlog.protocol=true",
			"-Dlog.level=ALL",
			--    "noverify",
			"-Xms1g",
			"--add-modules=ALL-SYSTEM",
			"--add-opens",
			"java.base/java.lang=ALL-UNNAMED",
			"--add-opens",
			"java.base/java.util=ALL-UNNAMED",
			"-javaagent:" .. home .. ".local/share/nvim/mason/packages/jdtls/lombok.jar",
			--    "-Xbootclasspath/a:"..home..".local/share/nvim/mason/packages/jdtls/lombok.jar",
			"-jar",
			vim.fn.glob(home .. ".local/share/nvim/mason/packages/jdtls/plugins/org.eclipse.equinox.launcher_*.jar"),
			"-configuration",
			home .. ".local/share/nvim/mason/packages/jdtls/config_linux",
			"-data",
			home .. ".workspace/." .. vim.fn.fnamemodify(root_dir, ":p:h:t"),
		},
		-- filetypes = { "java" },
		-- single_file_support = true,
		root_dir = root_dir,

		settings = {
			java = {
				signatureHelp = { enabled = true },
				contentProvider = { preferred = "fernflower" },
				completion = {
					favoriteStaticMembers = {
						"org.hamcrest.MatcherAssert.assertThat",
						"org.hamcrest.Matchers.*",
						"org.hamcrest.CoreMatchers.*",
						"org.junit.jupiter.api.Assertions.*",
						"java.util.Objects.requireNonNull",
						"java.util.Objects.requireNonNullElse",
						"org.mockito.Mockito.*",
					},
					filteredTypes = {
						"com.sun.*",
						"io.micrometer.shaded.*",
						"java.awt.*",
						"jdk.*",
						"sun.*",
					},
				},
				sources = {
					organizeImports = {
						starThreshold = 9999,
						staticStarThreshold = 9999,
					},
				},
				codeGeneration = {
					toString = {
						template = "${object.className}{${member.name()}=${member.value}, ${otherMembers}}",
					},
					hashCodeEquals = {
						useJava7Objects = true,
					},
					useBlocks = true,
				},
				configuration = {
					runtimes = {
--[[
        {
          name = "JavaSE-1.8",
          path = "/data/data/com.termux/files/usr/lib/jvm/java-8-openjdk/",
        },
--]]
        {
          name = "JavaSE-11",
          path = "/data/data/com.termux/files/usr/lib/jvm/java-11-openjdk/",
        },
        {
          name = "JavaSE-17",
          path = "/data/data/com.termux/files/usr/lib/jvm/openjdk/",
        },

						{
							name = "JavaSE-17",
							path = "/data/data/com.termux/files/usr/opt/openjdk/",
						},
					},
				},
			},
		},

		flags = {
			debounce_text_changes = 80,
			allow_incremental_sync = true,
		},
		capabilities = capabilities,
		on_attach = on_attach,
		init_options = {
			bundles = bundles,
			extendedClientCapabilities = extendedClientCapabilities,
		},
	}

	require("jdtls").start_or_attach(config)
end
return M
