


local util = require 'lspconfig.util'

--Enable (broadcasting) snippet capability for completion
local capabilities = vim.lsp.protocol.make_client_capabilities()
capabilities.textDocument.completion.completionItem.snippetSupport = true

require'lspconfig'.jsonls.setup {
	cmd = { "vscode-json-language-server", "--stdio" },
	filetypes = { "json", "jsonc" },
	root_dir = util.find_git_ancestor,
	single_file_support = true,
init_options = {
  provideFormatter = true
},

  capabilities = capabilities,
}
