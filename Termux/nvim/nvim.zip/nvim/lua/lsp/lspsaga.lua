require("lspsaga").setup({
	-- Default options
	-- 默认配置
	preview = {
		lines_above = 0,
		lines_below = 10,
	},
	scroll_preview = {
		scroll_down = "<C-f>",
		scroll_up = "<C-b>",
	},
	request_timeout = 2000,

	-- :Lspsaga lsp_finder
	-- 表示定义、引用和实现（仅当当前悬停的单词是函数、类型、类或接口时才显示）。
	finder = {
		edit = { "o", "<CR>" },
		vsplit = "s",
		split = "i",
		tabe = "t",
		quit = { "q", "<ESC>" },
	},
	
	-- :Lspsaga peek_definition
	-- 有两个命令，和 。该命令的工作方式类似于同名的 VSCode 命令，后者在可编辑的浮动窗口中显示目标文件。:Lspsaga peek_definition  :Lspsaga goto_definitionpeek_definition
	-- 作用，例如：快速定位函数并修改
	definition = {
		edit = "<C-c>o",
		vsplit = "<C-c>v",
		split = "<C-c>i",
		tabe = "<C-c>t",
		quit = "q",
		close = "<Esc>",
	},

	-- :Lspsaga goto_definition
	-- 跳转到悬停单词的定义，并显示信标突出显示。(不需要配置)
	
	-- :Lspsaga code_action
	-- num_shortcut 这是默认的，因此您可以通过按其相应的数字来快速运行代码操作。true
	code_action = {
		num_shortcut = true,
		keys = {
			-- string | table type
			quit = "q",
			exec = "<CR>",
		},
	},

	-- :Lspsaga Lightbulb
	-- 当有可能要执行代码操作时，将显示一个灯泡图标。
	lightbulb = {
		enable = true,
		enable_in_insert = true,
		sign = true,
		sign_priority = 40,
		virtual_text = true,
	},

	-- :Lspasga hover_doc
	-- 您应该安装 treeitter markdown 解析器，以便 Lspsaga 可以使用它来呈现悬停窗口。 您可以按两次键盘快捷键进入悬停窗口。
	-- 快速查看函数，变量的说明文档

	-- :Lspsaga diagnostic_jump_next
	-- 跳转到下一个诊断位置并显示信标突出显示。然后，Lspsaga 将显示代码操作。
	-- 使用 ，可以快速跳转到诊断浮动窗口中需要执行操作的行。go_action
	-- jump_num_shortcut- 默认值为 。跳转后，Lspasga 会自动将代码动作绑定到一个数字。之后，您可以按数字执行代码操作。浮动窗口关闭后，这些数字将不再绑定到相同的代码操作。true
	-- custom_msg用于自定义诊断跳转部分的字符串Msg
	-- custom_fix用于自定义诊断跳转部分的字符串Fix
	-- 还可以在通过 Lspsaga 函数使用诊断跳转时使用筛选器。该函数将表作为其参数。 它在功能上与 相同。:h vim.diagnostic.get_next
	-- require("lspsaga.diagnostic"):goto_prev({ severity = vim.diagnostic.severity.ERROR })
	diagnostic = {
		show_code_action = true,
		show_source = true,
		jump_num_shortcut = true,
		custom_fix = nil,
		custom_msg = nil,
		keys = {
			exec_action = "o",
			quit = "q",
			go_action = "g"
		},
	},

	-- :Lspsaga show_diagnostics
	-- 可以使用跳转到和使用跳转到诊断位置<C-w>w<CR>

	-- :Lspsaga rename
	-- 使用当前 LSP 重命名悬停的单词。
	-- mark用于参数。它用于标记要重命名悬停单词的文件。++project
	-- confirm- 标记文件后，按此键执行重命名。
	rename = {
		quit = "<C-c>",
		exec = "<CR>",
		mark = "x",
		confirm = "<CR>",
		in_select = true,
	},

	-- :Lspsaga outline
	-- 显示代码文件大纲
	outline = {
		win_position = "right",
		win_with = "",
		win_width = 30,
		show_detail = true,
		auto_preview = true,
		auto_refresh = true,
		auto_close = true,
		custom_sort = nil,
		keys = {
			jump = "o",
			expand_collapse = "u",
			quit = "q",
		},
	},

	-- :Lspsaga incoming_calls
	-- 运行 LSP 的呼叫层次结构/incoming_calls。
	callhierarchy = {
		show_detail = false,
		keys = {
			edit = "e",
			vsplit = "s",
			split = "i",
			tabe = "t",
			jump = "o",
			quit = "q",
			expand_collapse = "u",
		},
	},

	-- :Lspsaga outgoing_calls
	-- 运行 LSP 的呼叫层次结构/outgoing_calls。
	
	-- :Lspsaga symbols in winbar
	-- 文柱中的Lspsaga符号
	-- hide_keyword- 默认值为 。Lspsaga将隐藏一些关键字和临时变量，以使交易品种看起来更干净。true
	-- folder_level仅在 是 时有效。show_filetrue
	-- respect_root将尊重LSP的根源。如果这是，Lspsaga将忽略该选项。如果未使用 LSP 客户端，Lspsaga 将回退到使用文件夹级别。truefolder_level
	-- color_mode- 默认值为 。设置为 时，只有图标才会有颜色。truefalse
	symbol_in_winbar = {
		enable = true,
		separator = " ",
		hide_keyword = true,
		show_file = true,
		folder_level = 2,
		respect_root = false,
		color_mode = true,
	},

	-- :Lspsaga symbols in a custom winbar/statusline
	-- Lspsaga 提供了一个 API，您可以在自定义 winbar 或状态行中使用。
	--vim.wo.winbar / vim.wo.stl = require('lspsaga.symbolwinbar'):get_winbar(),

	-- :Lspsaga term_toggle
	-- 一个简单的浮动终端。
	-- 打开后，Ctrl + d 关闭

	-- :Lspsaga beacon
	-- 从浮动窗口跳转后，将显示信标以提醒您光标的位置.
	-- frequency闪烁频率
	beacon = {
		enable = true,
		frequency = 7,
	},

	-- :Lspsaga UI
	-- 默认 UI 选项
	ui = {
		-- 目前，只有圆形主题存在
		theme = "round",
		-- 这个选项仅支持Neovim 0.9
		title = true,
		-- 边框类型可以是单single、双double、圆rounded、实solid、阴影shadow。
		border = "double",
		winblend = 0,
		expand = "",
		collapse = "",
		preview = " ",
		code_action = "💡",
		diagnostic = "🐞",
		incoming = " ",
		outgoing = " ",
		hover = ' ',
		kind = {},
	},
	
})
