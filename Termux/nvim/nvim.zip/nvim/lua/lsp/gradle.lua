


local util = require 'lspconfig.util'

require'lspconfig'.gradle_ls.setup{
	cmd = { "gradle-language-server" },
	filetypes = { "groovy" },
	root_dir = util.root_pattern("settings.gradle"),

	init_options = {
  settings = {
    gradleWrapperEnabled = true
  }
},
}


