

require("toggleterm").setup{
	  --open_mapping = [[<c-\>]],
	  on_create = function(term)-- 函数在首次创建终端时运行
			print("open a new terminal！")
		end,
		
--[[
  on_close = fun(t: Terminal), -- 函数在终端关闭时运行
  on_stdout = fun(t: Terminal, job: number, data: string[], name: string) -- 回调函数用于处理stdout上的输出
  on_stderr = fun(t: Terminal, job: number, data: string[], name: string) -- 回调用于处理stderr上的输出
  on_exit = fun(t: Terminal, job: number, exit_code: number, name: string) -- 函数在终端进程退出时运行
--]]
  hide_numbers = true, -- 将数字列隐藏在toggleterm缓冲区中
  shade_filetypes = {},
  autochdir = true, -- 当neovim更改当前目录时，终端将在下次打开时更改自己的目录
--[[
  highlights = {
    -- 突出显示映射到突出显示组名称及其值的表
    -- 注意:这只是值的一个子集，这里放置的任何组都将被设置为终端窗口分割
    Normal = {
      guibg = "30",
    },
    NormalFloat = {
      link = 'Normal'
    },
    FloatBorder = {
      guifg = "30",
      guibg = "30",
    },
  },
--]]
  shade_terminals = true, --注意:这个选项优先于指定的高光，所以如果你指定了普通高光，你应该把这个设置为false
  shading_factor = '-30', -- 终端背景变亮的百分比，默认:-30(如果背景变亮则乘以-3)
  start_in_insert = true,
  insert_mappings = false, -- 是否在插入模式中应用开放映射
  terminal_mappings = true, -- 开放映射是否适用于已打开的终端
  persist_size = true,
  persist_mode = true, -- 如果设置为true(默认)，先前的终端模式将被记住
  direction = 'float',  --终端样式可选 'vertical' | 'horizontal' | 'tab' | 'float',
  close_on_exit = true, -- 当进程退出时关闭终端窗口
  shell = vim.o.shell, -- 更改默认shell
  auto_scroll = true, -- 在终端输出上自动滚动到底部
  -- 此字段仅在方向设置为'float'时才相关
  float_opts = {
    -- 边界键和“nvim_open_win”几乎一样
    -- 不过，关于边界的细节，请参阅:h nvim_open_win
    -- curved“弯曲”边界是一种自定义边界类型
    -- 本机不支持，但在此插件中实现。
    border =  'curved',  --边框可选 'single' | 'double' | 'shadow' | 'curved' | ... other options supported by win open
    --像' size '一样，宽度和高度可以是传递给当前终端的数字或函数
   -- width = 40,
    --height = 40,
    winblend = 3,
  },
  --[[
  winbar = {
    enabled = false,
    name_formatter = function(term) --  term: Terminal
      return term.name
    end
  },
--]]
}



--[[
●可选参数
Terminal:new {
  cmd = string -- 在创建终端时执行的命令。“高级”top
  direction = string -- 终端的布局，与主配置选项相同
  dir = string -- 终端的目录
  close_on_exit = bool -- 当进程退出时关闭终端窗口
  highlights = table -- 有亮点的表格
  env = table -- key:value 键:包含传递给jobstart()的环境变量的值表
  clear_env = bool -- 只使用来自' env '的环境变量，传递给jobstart()
  on_open = fun(t: Terminal) -- 
  on_close = fun(t: Terminal) -- 
  auto_scroll = boolean -- 在终端输出上自动滚动到底部
  -- 用于处理输出的回调
  on_stdout = fun(t: Terminal, job: number, data: string[], name: string) -- 回调函数用于处理stdout上的输出
  on_stderr = fun(t: Terminal, job: number, data: string[], name: string) --回调用于处理stderr上的输出
  on_exit = fun(t: Terminal, job: number, exit_code: number, name: string) -- 函数在终端进程退出时运行
}

●用法
	［1］:ToggleTerm  （创建终端，不支持cmd）
		:ToggleTerm size=40 dir=~/
	
	［2］:TermExec （创建终端，支持cmd）
		:TermExec cmd="echo Hello World " dir=~/
	［3］:ToggleTermToggleAll （显示全部隐藏的终端）


:ToggleTermSendCurrentLine <T_ID>：用光标发送您站立的整行
:ToggleTermSendVisualLines <T_ID>：发送视觉对象选择中的所有（整行）行
:ToggleTermSendVisualSelection <T_ID>：仅发送可视选择的文本（这可以是文本块或单行中的选择）
<T_ID是一个可选的终端 ID 参数，它定义了我们应该将线路发送到哪里。 如果未提供参数，则默认值为first terminal
--]]