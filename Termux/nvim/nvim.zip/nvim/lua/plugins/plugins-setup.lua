-- 自动安装packer
vim.opt.runtimepath:append("~/.local/share/nvim/site")
local ensure_packer = function()
	local fn = vim.fn
	local install_path = fn.stdpath('data') .. '/site/pack/packer/start/packer.nvim'
	if fn.empty(fn.glob(install_path)) > 0 then
		fn.system({ 'git', 'clone', '--depth', '1', 'https://github.com/wbthomason/packer.nvim', install_path })
		vim.cmd [[packadd packer.nvim]]
		return true
	end
	return false
end




local packer_bootstrap = ensure_packer()

-- 保存此文件自动更新安装软件
-- 注意PackerCompile改成了PackerSync
-- plugins.lua改成了plugins-setup.lua，适应本地文件名字
vim.cmd([[
	augroup packer_user_config
		autocmd!
		autocmd BufWritePost plugins-setup.lua source <afile> | PackerSync
	augroup end
]])


return require('packer').startup({
	--packer配置
	config = {
		ensure_dependencies  = true, -- Should packer install plugin dependencies?
		snapshot             = nil, -- Name of the snapshot you would like to load at startup
		--  snapshot_path = join_paths(stdpath 'cache', 'packer.nvim'), -- Default save directory for snapshots
		--  package_root   = util.join_paths(vim.fn.stdpath('data'), 'site', 'pack'),
		--  compile_path = util.join_paths(vim.fn.stdpath('config'), 'plugin', 'packer_compiled.lua'),

		plugin_package       = 'packer', -- The default package for plugins
		max_jobs             = nil, -- Limit the number of simultaneous jobs. nil means no limit
		auto_clean           = true, -- During sync(), remove unused plugins
		compile_on_sync      = true, -- During sync(), run packer.compile()
		disable_commands     = false, -- Disable creating commands
		opt_default          = false, -- Default to using opt (as opposed to start) plugins
		transitive_opt       = true, -- Make dependencies of opt plugins also opt by default
		transitive_disable   = true, -- Automatically disable dependencies of disabled plugins
		auto_reload_compiled = true, -- Automatically reload the compiled file after creating it.
		preview_updates      = false, -- If true, always preview updates before choosing which plugins to update, same as `PackerUpdate --preview`.

		git                  = {
			cmd = 'git', -- The base command for git operations
			subcommands = { -- Format strings for git subcommands
				update         = 'pull --ff-only --progress --rebase=false',
				install        = 'clone --depth %i --no-single-branch --progress',
				fetch          = 'fetch --depth 999999 --progress',
				checkout       = 'checkout %s --',
				update_branch  = 'merge --ff-only @{u}',
				current_branch = 'branch --show-current',
				diff           = 'log --color=never --pretty=format:FMT --no-show-signature HEAD@{1}...HEAD',
				diff_fmt       = '%%h %%s (%%cr)',
				get_rev        = 'rev-parse --short HEAD',
				get_msg        = 'log --color=never --pretty=format:FMT --no-show-signature HEAD -n 1',
				submodules     = 'submodule update --init --recursive --progress'
			},
			depth = 1, -- Git clone depth
			clone_timeout = 60, -- Timeout, in seconds, for git clones
			default_url_format = 'https://github.com/%s' -- Lua format string used for "aaa/bbb" style plugins
		},

		display              = {
			non_interactive = false, -- If true, disable display windows for all operations
			compact = false, -- If true, fold updates results by default
			--浮动窗口
			open_fn = require('packer.util').float, -- An optional function to open a window for packer's display
			open_cmd = '65vnew \\[packer\\]', -- An optional command to open a window for packer's display
			working_sym = '⟳', -- The symbol for a plugin being installed/updated
			error_sym = '✗', -- The symbol for a plugin with an error in installation/updating
			done_sym = '✓', -- The symbol for a plugin which has completed installation/updating
			removed_sym = '-', -- The symbol for an unused plugin which was removed
			moved_sym = '→', -- The symbol for a plugin which was moved (e.g. from opt to start)
			header_sym = '━', -- The symbol for the header line in packer's display
			show_all_info = true, -- Should packer show all update details automatically?
			prompt_border = 'double', -- Border style of prompt popups.
			keybindings = { -- Keybindings for the display window
				quit = 'q',
				toggle_update = 'u', -- only in preview
				continue = 'c', -- only in preview
				toggle_info = '<CR>',
				diff = 'd',
				prompt_revert = 'r',
			}
		},
		luarocks             = {
			python_cmd = 'python' -- Set the python command to use for running hererocks
		},
		log                  = { level = 'warn' }, -- The default print log level. One of: "trace", "debug", "info", "warn", "error", "fatal".
		profile              = {
			enable = false,
			threshold = 1, -- integer in milliseconds, plugins which load faster than this won't be shown in profile output
		},
		autoremove           = false, -- Remove disabled or unused plugins without prompting the user
	},

	-- 插件写这里，会自动下载
	function(use)
		-- use '仓库名'
		use 'wbthomason/packer.nvim'
		use 'folke/tokyonight.nvim' --tokyonight主题
		use 'navarasu/onedark.nvim' --onedark主题
		use {'morhetz/gruvbox',tag = "*",}	--gruvbox主题
		use 'tomasr/molokai'	--molokai主题
		use 'altercation/vim-colors-solarized'	--vim-colors-solarized主题
		--use {'sonph/onehalf',
		--rtp = "vim",}	--onehalf主题
		
		--use {'dracula/vim',tag = "*",}	--dracula主题
		--use 'chriskempson/base16-vim'	--base16-vim主题
		--use 'jnurmine/Zenburn'	--Zenburn主题
		use 'gosukiwi/vim-atom-dark'	--vim-atom-dark主题
		use 'NLKNguyen/papercolor-theme'	--papercolor-theme主题
		--use 'jacoborus/tender.vim'	--tender.vim主题
		--use 'sjl/badwolf'	--badwolf主题
		use 'arcticicestudio/nord-vim'	--nord-vim主题
		--use 'sindresorhus/hyper-snazzy'	--hyper-snazzy主题
		use {'rakr/vim-one',tag = "*",}	--vim-one主题
		--use 'mhartington/oceanic-next'	--oceanic-next主题
		--use 'ayu-theme/ayu-vim'	--ayu-vim主题
		use 'kyoz/purify'	--purify主题
		--use 'drewtempelmeyer/palenight.vim'	--palenight.vim主题

		use {'nvim-lualine/lualine.nvim', --底部状态栏
			requires = { 'kyazdani42/nvim-web-devicons', opt = true } --字体图标支持
		}
		use {'nvim-tree/nvim-tree.lua', --文档树
			tag = 'nightly' -- optional, updated every week. (see issue #1193)
		}
		use "nvim-tree/nvim-web-devicons"  --字体图标支持
		use {'nvim-treesitter/nvim-treesitter', --根据代码进行语法颜色区分（*）
			run = ':TSUpdate'
		}
		use 'p00f/nvim-ts-rainbow' --不同的方法和类，括号用不同的颜色区分
		use { "akinsho/toggleterm.nvim",   --浮动终端
		tag = '*',}
		use {'glepnir/dashboard-nvim',} --启动页面
		
		use 'christoomey/vim-tmux-navigator' --终端页面切换
		use({"giusgad/pets.nvim",--终端显示小动物（需要GUI支持，列如kitty终端）
			requires = {
				"edluffy/hologram.nvim",
				"MunifTanjim/nui.nvim",
			}
		})
		use 'mfussenegger/nvim-jdtls' --针对Java Lsp，用于支持eclipse.jdt.ls的扩展

		use {"williamboman/mason.nvim", --lsp和dap的下载器与管理
			"williamboman/mason-lspconfig.nvim", --连接mason.nvim与nvim-lspconfig的中间插件
			"neovim/nvim-lspconfig", --lsp客户端配置文件合集
		}
		use 'folke/lsp-colors.nvim' --为lsp客户端设置配色方案
		use({"glepnir/lspsaga.nvim", --轻量级Lsp插件，具有高性能UI，功能非常强（显示类、方法信息，根据代码创建大纲，灯泡💡提示，浮动终端等等）
			branch = "main",
			requires = {
				{ "nvim-treesitter/nvim-treesitter" }
			}
		})
		use 'hrsh7th/cmp-nvim-lsp-signature-help' --Lsp插件，功能:提示方法，函数的参数需要
		use 'j-hui/fidget.nvim' --Lsp右下角信息提示
		use 'hrsh7th/nvim-cmp' --代码补全核心插件
		use 'hrsh7th/cmp-nvim-lsp' --根据lsp服务器进行补全提示
		use 'hrsh7th/cmp-cmdline' --nvim命令行模式提示
		use 'f3fora/cmp-spell' --英语单词拼写辅助
		use 'hrsh7th/cmp-path' --路径补全支持
		use 'hrsh7th/cmp-buffer' --nvim-cmp的缓冲词来源
		use {"windwp/nvim-autopairs", }--自动补全括号（输入左括号，光标移动到中间，输入右括号，跳出括号）
		
		--use { 'tzachar/cmp-tabnine', --AI补全（暂时没有支持aarch64）
		--	run = './install.sh',
		--	requires = 'hrsh7th/nvim-cmp' }
			
		use({"L3MON4D3/LuaSnip", --代码块支持
			tag = "*",
			run = "make install_jsregexp"
		})
		use 'saadparwaiz1/cmp_luasnip' --代码块支持
		use "rafamadriz/friendly-snippets" --友好的代码块支持
		use 'jose-elias-alvarez/null-ls.nvim' --帮助程序来简化生成过程和 将命令行进程的输出转换为 LSP 友好的格式
		use 'mfussenegger/nvim-dap' --代码调试debug
		use 'rcarriga/cmp-dap' --代码调试（*）
		use { "rcarriga/nvim-dap-ui"} --调试页面UI支持
		use 'theHamsta/nvim-dap-virtual-text' --此插件为nvim-dap添加了虚拟文本支持（显示变量的实值）
		use 'folke/which-key.nvim' --快捷键提示
		use 'numToStr/Comment.nvim' --自动注释代码
		use { 'akinsho/bufferline.nvim', --顶部显示buffer缓冲区
			tag = "v3.*",
			requires = 'nvim-tree/nvim-web-devicons' }
		use 'lewis6991/gitsigns.nvim' --左则Git提示
		use {'nvim-telescope/telescope.nvim', --高度可扩展的模糊查找器
			tag = '0.1.1', -- or , branch = '0.1.x',
			requires = {  'nvim-lua/plenary.nvim'  }
		}
		use 'chentoast/marks.nvim' --一个行标记
		use 'norcalli/nvim-colorizer.lua' --高性能的高亮插件
		use {'JuanZoran/Trans.nvim', --英文翻译（单词包128M解压≈1.2G）
			requires = 'kkharji/sqlite.lua',}
		use({"iamcco/markdown-preview.nvim", --markdown预览插件
			run = "cd app && npm install",
		})
		use 'Yggdroot/indentLine' --代码缩进线
		--use 'weirongxu/plantuml-previewer.vim'  --写流程图的插件（暂时不需要）
		use 'tpope/vim-dadbod' --数据库支持插件
		use {'kristijanhusak/vim-dadbod-ui', --数据库可视插件
		after = 'vim-dadbod',}

		if packer_bootstrap then
			require('packer').sync()
		end
	end,
})




--[[
use {
  'myusername/example',        -- The plugin location string
  -- The following keys are all optional
  disable = boolean,           -- Mark a plugin as inactive
  as = string,                 -- Specifies an alias under which to install the plugin
  installer = function,        -- Specifies custom installer. See "custom installers" below.
  updater = function,          -- Specifies custom updater. See "custom installers" below.
after = string or list，——指定在此插件之前加载的插件。参见下面的“排序”
rtp = string，——指定要添加到runtimepath的插件的子目录。
opt = boolean，——手动将插件标记为可选。
bufread = boolean，——手动指定插件加载后是否需要bufread
branch = string，——指定要使用的git分支
tag = string，——指定要使用的git标记。支持“*”为“最新标签”
commit = string，——指定要使用的git提交
lock = boolean，——在updates/sync中跳过更新此插件。还清洗。
  run = string, function, or table, -- Post-update/install hook. See "update/install hooks".
  requires = string or list,   -- Specifies plugin dependencies. See "dependencies".
  rocks = string or list,      -- Specifies Luarocks dependencies for the plugin
  config = string or function, -- Specifies code to run after this plugin is loaded.
  -- The setup key implies opt = true
  setup = string or function,  -- Specifies code to run before this plugin is loaded. The code is ran even if
                               -- the plugin is waiting for other conditions (ft, cond...) to be met.
  -- The following keys all imply lazy-loading and imply opt = true
  cmd = string or list,        -- Specifies commands which load this plugin. Can be an autocmd pattern.
  ft = string or list,         -- Specifies filetypes which load this plugin.
  keys = string or list,       -- Specifies maps which load this plugin. See "Keybindings".
  event = string or list,      -- Specifies autocommand events which load this plugin.
  fn = string or list          -- Specifies functions which load this plugin.
  cond = string, function, or list of strings/functions,   -- Specifies a conditional test to load this plugin
  module = string or list      -- Specifies Lua module names for require. When requiring a string which starts
                               -- with one of these module names, the plugin will be loaded.
  module_pattern = string/list -- Specifies Lua pattern of Lua module names for require. When
                               -- requiring a string which matches one of these patterns, the plugin will be loaded.
}
--]]










