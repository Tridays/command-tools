
--设置一些图标
local kind_icons = {
      Class = " ",
      Color = " ",
      Constant = "ﲀ ",
      Constructor = " ",
      Enum = "練",
      EnumMember = " ",
      Event = " ",
      Field = " ",
      File = "",
      Folder = " ",
      Function = " ",
      Interface = "ﰮ ",
      Keyword = " ",
      Method = " ",
      Module = " ",
      Operator = "",
      Property = " ",
      Reference = " ",
      Snippet = " ",
      Struct = " ",
      Text = " ",
      TypeParameter = " ",
      Unit = "塞",
      Value = " ",
      Variable = " ",
    }



--L3MON4D3/LuaSnip🍎
--代码块片段的加载
--安装一个提供片段的插件并调用，例可选 luasnip.loaders.from_snipmate
require("luasnip.loaders.from_vscode").lazy_load()
--require("luasnip.loaders.from_vscode").load( paths = {    --加载自定义代码块片段，一个json文件
--	vim.fn.stdpath("config").."/my-snippet"
--})



-- Set up hrsh7th/nvim-cmp🍎
local cmp = require'cmp'
cmp.setup({
	snippet = {
		expand = function(args)
			require'luasnip'.lsp_expand(args.body)
		end,
	},
	
	
	--提示框样式
	window = {
		completion = cmp.config.window.bordered(),
		documentation = cmp.config.window.bordered(),
	},
	
	--控制键绑定
	mapping = cmp.mapping.preset.insert({
		['<C-j>'] = cmp.mapping.select_prev_item(),  --在提示框内快速向上移动 (使用Ctrl + j)	 (默认可使用↑↓)
		['<C-k>'] = cmp.mapping.select_next_item(),  --在提示框内快速下移动
		['<C-b>'] = cmp.mapping.scroll_docs(-4),  --快速滚动说明文档(没测试成功)
		['<C-f>'] = cmp.mapping.scroll_docs(4),  --同上
		['<C-e>'] = cmp.mapping.abort(),	-- 取消补全，esc也可以退出
		['<CR>'] = cmp.mapping.confirm({ select = true }),  --做一次选择
--[[
		["<Tab>"] = cmp.mapping(function(fallback)
			if cmp.visible() then
				cmp.select_next_item()
			elseif luasnip.expandable() then
				luasnip.expand()
			elseif luasnip.expand_or_jumpable() then
				luasnip.expand_or_jump()
			elseif check_backspace() then
				fallback()
			else
				fallback()
			end
		end, {
			"i",
			"s",
		}),
--]]
			["<S-Tab>"] = cmp.mapping(function(fallback)
			if cmp.visible() then
				cmp.select_prev_item()
			elseif luasnip.jumpable(-1) then
				luasnip.jump(-1)
			else
				fallback()
			end
		end, {
			"i",
			"s",
		}),

	}),
	
	--控制提示框，每行最左边提示的东西
	formatting = {
		fields = { "kind", "abbr", "menu" },
		format = function(entry, vim_item)
			--样式二选一
			--vim_item.kind = string.format("%s", kind_icons[vim_item.kind])
			vim_item.kind = string.format("%s %s", kind_icons[vim_item.kind], vim_item.kind)
			
			--提示代码块来自于哪个服务器
			vim_item.menu = ({
				nvim_lsp = "[Lsp]",
				cmp_tabnine = "[Tabnine]",
				--nvim_lua = "[NVIM_LUA]",
				luasnip = "[Snippet]",
				buffer = "[Buffer]",
				spell = "[Spell]",
				path = "[Path]",
			})[entry.source.name]
				return vim_item
		end,
	},

	--代码块的提示来源(代码候选框)（核心部分）
	sources = cmp.config.sources({
		{ name = 'nvim_lsp' }, -- hrsh7th/cmp-nvim-lsp🍎
		{ name = "cmp_tabnine" },  --tzachar/cmp-tabnine🍎
		{ name = 'luasnip',  -- For luasnip users.  --saadparwaiz1/cmp_luasnip🍎
			option = {
				--show_autosnippets = true ,
				use_show_condition = false,
			},
		},	
		
		{ name = 'path', -- --hrsh7th/cmp-path🍎
			option = {
				-- 指定已完成的目录名称是否应包含尾部斜杠。启用此选项会使此源的行为类似于 Vim 的内置路径补全。
				trailing_slash = true,
				--指定完成菜单中的目录名称是否应包含尾部斜杠。
				label_trailing_slash = true,
				--默认值：返回当前缓冲区的当前工作目录
				--指定相对路径的基目录。
				--get_cwd = function()
				--	return true
				--end,
			},
		},
		
        { name = 'spell',  --f3fora/cmp-spell🍎（未）
		  option = {
				keep_all_entries = false,
				enable_in_context = function()
					return true
				end,
		  },
		},
	},{{name = "buffer", {option = {
		keyword_pattern = [[\k\+]],
		get_bufnrs = function()
			return vim.api.nvim_list_bufs()
		end,
	}}},}),

	--其他的一下选项
	flags = {
		debounce_text_changes = 150,
	},
	confirm_opts = {
		behavior = cmp.ConfirmBehavior.Replace,
		select = false,
	},
	experimental = {
		ghost_text = true,
	},
})





--cmp-dap
require("cmp").setup({
  enabled = function()
    return vim.api.nvim_buf_get_option(0, "buftype") ~= "prompt"
        or require("cmp_dap").is_dap_buffer()
  end
})

require("cmp").setup.filetype(
	{ "dap-repl", "dapui_watches", "dapui_hover" },
	{sources = {
		{ name = "dap" },
		{ name = "nvim_lsp_signature_help" },
	},
})



-- spell英文单词补全提示（英语六级大佬可选择 false）
vim.opt.spell = true
vim.opt.spelllang = { 'en_us' }

--hrsh7th/cmp-cmdline🍎
  -- 在nvim命令行输入  '/' 和 '?' 提供搜索 "字符" 的位置信息（使用Tab键选择）
  -- 在nvim编辑模式，输入 '~' 可进行路径补全
cmp.setup.cmdline({ '/', '?' }, {
	mapping = cmp.mapping.preset.cmdline(),
	sources = {
		{ name = 'buffer' }
	}
})
  -- 在nvim命令行输入  ':' 提供信息
cmp.setup.cmdline({':'}, {
	mapping = cmp.mapping.preset.cmdline(),
	sources = cmp.config.sources({
		{ name = 'path' }
		}, {
		{ name = 'cmdline',
			option = {
				ignore_cmds = { 'Man', '!' }  --忽略字符串提示
			}
		}
	})
})

