
--[[
"giusgad/pets.nvim"
"MunifTanjim/nui.nvim"
"edluffy/hologram.nvim",
--]]
require("pets").setup({
  -- your options here
  
  row = 1, -- the row (height) to display the pet at (must be at least 1 and at most 10)
  col = 0, -- the column to display the pet at (set to high number to have it stay still on the right side)
  speed_multiplier = 1, -- you can make your pet move faster/slower. If slower the animation will have lower fps.
  default_pet = "cat", -- the pet to use for the PetNew command
  default_style = "brown", -- the style of the pet to use for the PetNew command
  random = false, -- wether to use a random pet for the PetNew command, ovverides default_pet and default_style
  death_animation = true, -- animate the pet's death, set to false to feel less guilt
  popup = { -- popup options, try changing these if you see a rectangle around the pets
    width = "50%", -- can be a string with percentage like "45%" or a number of columns like 45
    winblend = 100, -- winblend value - see :h 'winblend' - only used if avoid_statusline is false
    hl = { Normal = "Normal" }, -- hl is only set if avoid_statusline is true, you can put any hl group instead of "Normal"
    avoid_statusline = false, -- if winblend is 100 then the popup is invisible and covers the statusline, if that
    -- doesn't work for you then set this to true and the popup will use hl and will be spawned above the statusline (hopefully)
  }

})


--[[
｛
Row = 1，——显示宠物的行(高度)(必须至少为1，最多为10)
Col = 0，—显示宠物的列(设置为高数值，使其保持静止在右侧)
Speed_multiplier = 1，—你可以让你的宠物移动得更快/更慢。如果速度较慢，动画的帧数就会较低。
default_pet = "cat"，——用于PetNew命令的宠物
default_style = "brown"，——PetNew命令使用的宠物的样式
random = false，——是否为PetNew命令使用随机pet，覆盖default_pet和default_style
Death_animation = true，——动画宠物的死亡，设置为false以减少罪恶感
Popup ={——弹出选项，尝试改变这些，如果你看到一个矩形周围的宠物
Width = "30%"，——可以是百分比为"45%"的字符串，也可以是列数为45的字符串
Winblend = 100，——Winblend值-参见:h ' Winblend ' -仅在avoid_statusline为false时使用
hl = {Normal = "Normal"}，——hl只有在avoid_statusline为真时才设置，你可以把任何hl组代替"Normal"
Avoid_statusline = false，——如果winblend为100，则弹出窗口是不可见的，并覆盖状态行
——对你不起作用，然后将其设置为true，弹出窗口将使用hl并将在状态线上方生成(希望如此)
｝
｝
--]]