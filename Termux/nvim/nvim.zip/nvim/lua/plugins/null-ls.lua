local null_ls = require("null-ls")
local formatting = null_ls.builtins.formatting


null_ls.setup({
	debug = false,
	--更多代码格式化源请参考（https://github.com/jose-elias-alvarez/null-ls.nvim/blob/main/doc/BUILTINS.md）
    sources = {
        --formatting.prettier.with({ extra_args = { "--no-semi", "--single-quote", "--jsx-single-quote"}}),
        --formatting.black.with({ extra_args = { "--fast" }}),
        --formatting.yapf,
        formatting.eslint,
        formatting.stylua,
		--formatting.flake8,
		formatting.autopep8,
    },
})







