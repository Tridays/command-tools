local db = require('dashboard')
db.setup({
    theme = 'hyper',
    config = {
      week_header = {
       enable = true,
       append = {
       "宜：祈福，开学，开市，求医，成服",
       "忌：词讼，安門，移徙",
       },
      },
      shortcut = {
        { desc = ' Update', group = '@property', action = 'Lazy update', key = 'u' },
        {
          desc = ' Files',
          group = 'Label',
          action = 'Telescope find_files',
          key = 'f',
        },
        {
          desc = ' Apps',
          group = 'DiagnosticHint',
          action = 'Telescope app',
          key = 'a',
        },
        {
          desc = ' dotfiles',
          group = 'Number',
          action = 'Telescope dotfiles',
          key = 'd',
        },
      },
    },
  })





