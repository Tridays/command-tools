
vim.cmd[[
" 禁用打开json文件显示缩进线
let g:vim_json_conceal=0
" 禁用打开markdown文件显示缩进线
let g:markdown_syntax_conceal=0
" 默认不打开缩进线
" let g:indentLine_enabled = 1
]]


