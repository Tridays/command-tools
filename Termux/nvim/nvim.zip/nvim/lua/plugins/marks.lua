require'marks'.setup {
  -- 是否映射 keybind
  default_mappings = false,
  -- 内装式标记来显示哪一个. default {}
  builtin_marks = { ".", "<", ">", "^" },
  -- 运动是否循环回到缓冲区的开头/结尾。 默认为true
  cyclic = true,
  -- 修改大写标记后是否更新shada文件。 default false
  force_write_shada = false,
  -- 重绘标志/重新计算标记位置的频率（以毫秒为单位）。
   -- 更高的值将有更好的性能，但可能会导致视觉延迟，
   -- 而较低的值可能会导致性能下降。 默认 150。
  refresh_interval = 250,
  -- 每种类型标记的标记优先级 - 内置标记、大写标记、小写标记
   -- 标记和书签。
   -- 可以是包含所有键/没有键的表，也可以是单个数字，在这种情况下
   --优先权适用于所有商标。
   -- 默认 10。
  sign_priority = { lower=10, upper=15, builtin=8, bookmark=20 },
  -- 禁用特定文件类型的标记跟踪。 default {}
  excluded_filetypes = {},
   -- marks.nvim 允许你配置最多 10 个书签组，每个都有自己的
   -- 签名/虚拟文本。 书签可用于将位置组合在一起并快速移动
   -- 跨多个缓冲区。 默认符号为 '!@#$%^&*()'（从 0 到 9），并且
   -- 默认 virt_text 是“”。
  bookmark_0 = {
    sign = "",
    --virt_text = "插旗1标记",
    virt_text = "插旗1标记",
    -- 在此组中设置书签时明确提示输入虚拟线注释。
    -- defaults to false.
    annotate = true,
  },
  bookmark_1 = {
    sign = "",
    virt_text = "插旗2标记",
    -- 在此组中设置书签时明确提示输入虚拟线注释。
    -- defaults to false.
    annotate = true,
  },
  bookmark_2 = {
    sign = "⚑",
    virt_text = "插旗3标记",
    -- 在此组中设置书签时明确提示输入虚拟线注释。
    -- defaults to false.
    annotate = true,
  },
  bookmark_3 = {
    sign = "",
    virt_text = "插钉子标记",
    -- 在此组中设置书签时明确提示输入虚拟线注释。
    -- defaults to false.
    annotate = true,
  },
  bookmark_4 = {
    sign = "",
    virt_text = "插！标记",
    -- 在此组中设置书签时明确提示输入虚拟线注释。
    -- defaults to false.
    annotate = true,
  },
  bookmark_5 = {
    sign = "",
    virt_text = "插i标记",
    -- 在此组中设置书签时明确提示输入虚拟线注释。
    -- defaults to false.
    annotate = true,
  },
  bookmark_6 = {
    sign = "",
    virt_text = "插打勾标记",
    -- 在此组中设置书签时明确提示输入虚拟线注释。
    -- defaults to false.
    annotate = true,
  },
bookmark_7 = {
    sign = "",
    virt_text = "插打叉标记",
    -- 在此组中设置书签时明确提示输入虚拟线注释。
    -- defaults to false.
    annotate = true,
  },
bookmark_8 = {
    sign = "",
    virt_text = "插手势标记",
    -- 在此组中设置书签时明确提示输入虚拟线注释。
    -- defaults to false.
    annotate = true,
  },
bookmark_9 = {
    sign = "",
    virt_text = "插铃铛标记",
    -- 在此组中设置书签时明确提示输入虚拟线注释。
    -- defaults to false.
    annotate = true,
  },
  mappings = {}
}


--[[

mx 设置标记 x
     m, 设置下一个可用的字母（小写）标记
     米; 在当前行切换下一个可用标记
     dmx 删除标记 x
     dm- 删除当前行的所有标记
     dm<space> 删除当前缓冲区中的所有标记
     m] 移动到下一个标记
     m[ 移动到上一个标记
     m：预览标记。 这将提示您输入特定标记
                     预览; 按 <cr> 预览下一个标记。
                    
     m[0-9] 添加书签组[0-9]中的一个书签。
     dm[0-9] 删除书签组[0-9]中的所有书签。
     m} 移动到与下一个书签具有相同类型的下一个书签
                     光标。 跨缓冲区工作。
     m{ 移动到与下一个书签类型相同的上一个书签
                     光标。 跨缓冲区工作。
     dm= 删除光标下的书签。





set_next 在光标处设置下一个可用的小写标记。
   toggle 在光标处切换下一个可用标记。
   delete_line 删除当前行上的所有标记。
   delete_buf 删除当前缓冲区中的所有标记。
   next 转到缓冲区中的下一个标记。
   prev 转到缓冲区中的上一个标记。
   preview 预览标记（将等待用户输入）。 按 <cr> 仅预览下一个标记。
   set 设置一个字母标记（将等待输入）。
   delete 删除一个字母标记（将等待输入）。

   set_bookmark[0-9] 设置组[0-9] 中的书签。
   delete_bookmark[0-9] 删除组[0-9] 中的所有书签。
   delete_bookmark 删除光标下的书签。
   next_bookmark 移动到与当前书签具有相同类型的下一个书签
                          光标下的书签。
   prev_bookmark 移动到上一个与当前书签类型相同的书签
                          光标下的书签。
   next_bookmark[0-9] 移动到同一组类型的下一个书签。 作品由
                          首先根据行号，然后根据缓冲区
                          数字。
   prev_bookmark[0-9] 移动到同一组类型的上一个书签。 作品由
                          首先根据行号，然后根据缓冲区
                          数字。
   annotate 提示用户输入随后放置的虚拟线注释
                          在书签上方。 需要 neovim 0.6+，默认情况下不映射。
--]]