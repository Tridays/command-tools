

local M = {}
--用于更改主题
function Change(theme)
	file = os.getenv("HOME").."/.config/nvim/lua/plugins/Theme.lua"
	io.output(file):write(theme)
	print("配置已保存"..file)
	io.close()
	return nil;
end

--tokyonight主题
function M.tokyonight(x, y)
	--"选择主题。可选tokyonight tokyonight-night tokyonight-storm tokyonight-day tokyonight-moon
	vim.cmd("colorscheme "..x)
	if(y)
	then
		Change("require(\"plugins/Beautify\").tokyonight(\""..x.."\",false)")
	end
end

--onedark主题
function M.onedark(x,y)
	--选择主题。可选dark, darker, cool, deep, warm, warmer, light
	require('onedark').setup {
	    style = x
	}
	require('onedark').load()
	if(y)
	then
		Change("require(\"plugins/Beautify\").onedark(\""..x.."\",false)")
	end
end

--gruvbox主题
function M.gruvbox(x,y)
	--"选择背景颜色。可选light dark
	vim.cmd("set background="..x)
	----其他配置
	vim.cmd[[
		"启用粗体文本
		let g:gruvbox_bold = 1
		"启用斜体文本
		"let g:gruvbox_italic = '1'
		"启用透明背景
		"let g:gruvbox_transparent_bg = '0'
		"启用带下划线的文本。
		"let g:gruvbox_underline = '1'
		"更改暗模式对比度。可选soft medium hard
		"let g:gruvbox_contrast_dark = 'soft'
		"更改灯光模式对比度。可选soft medium hard
		let g:gruvbox_contrast_light =  'soft'
		" 使用 256 调色板（适合与 gruvbox 调色板外壳脚本配对）。可选 16 256
		"let g:gruvbox_termcolors = 256
		colorscheme gruvbox
	]]
	if(y)
	then
		Change("require(\"plugins/Beautify\").gruvbox(\""..x.."\",false)")
	end
end

--vim-colors-solarized主题
function M.vim_colors_solarized(x, y)
	--"选择主题。可选dark light
	if(x == "dark")
	then
		vim.cmd[[
		syntax enable
		set background=dark
		]]	
	else
		vim.cmd[[
		syntax enable
		set background=light
		]]		
	end
	vim.cmd("colorscheme solarized")
	if(y)
	then
		Change("require(\"plugins/Beautify\").vim_colors_solarized(\""..x.."\",false)")
	end
end

--vim-atom-dark主题
function M.vim_atom_dark(x, y)
	--"选择主题。可选dark light
	vim.cmd("colorscheme "..x)
	if(y)
	then
		Change("require(\"plugins/Beautify\").vim_atom_dark(\""..x.."\",false)")
	end
end

--papercolor-theme主题
function M.papercolor_theme(x, y)
	--"选择主题。可选dark ligth
	if(x == "dark")
	then
		vim.cmd[[
		syntax enable
		set background=dark
		]]	
	else
		vim.cmd[[
		syntax enable
		set background=light
		]]		
	end
	vim.cmd("colorscheme PaperColor")
	if(y)
	then
		Change("require(\"plugins/Beautify\").papercolor_theme(\""..x.."\",false)")
	end
end

--nord-vim主题
function M.nord_vim(x, y)
	--"选择主题。可选tokyonight tokyonight-night tokyonight-storm tokyonight-day tokyonight-moon
	vim.cmd("colorscheme "..x)
	if(y)
	then
		Change("require(\"plugins/Beautify\").nord_vim(\""..x.."\",false)")
	end
end

--vim-one主题
function M.vim_one(x, y)
	--"选择主题。可选tokyonight tokyonight-night tokyonight-storm tokyonight-day tokyonight-moon
	if(x == "dark")
	then
		vim.cmd[[
		syntax enable
		set background=dark
		]]	
	else
		vim.cmd[[
		syntax enable
		set background=light
		]]		
	end
	vim.cmd("colorscheme one")
	if(y)
	then
		Change("require(\"plugins/Beautify\").vim_one(\""..x.."\",false)")
	end
end

--purify主题
function M.purify(x, y)
	--"选择主题。可选
	vim.opt.runtimepath:append("~/.local/share/nvim/site/pack/packer/start/purify/vim")
	vim.cmd("colorscheme purify")
	if(x == "dark")
	then
		vim.cmd[[
		set background=dark
		hi Normal guibg=#252834 ctermbg=234
		]]	
	elseif(x == "brown")
	then
		vim.cmd[[
		set background=dark
		hi Normal guibg=#333333 ctermbg=234
		]]		
	end
	if(y)
	then
		Change("require(\"plugins/Beautify\").purify(\""..x.."\",false)")
	end
end

--lualine状态栏
function M.lualine(x, y)
	--"选择主题。可选
	require('lualine').setup{options = { theme = x }}
	s = "return \""..x.."\""
	file = os.getenv("HOME").."/.config/nvim/lua/plugins/line.lua"
	io.output(file):write(s)
	print("配置已保存"..file)
	io.close()
end
return M




