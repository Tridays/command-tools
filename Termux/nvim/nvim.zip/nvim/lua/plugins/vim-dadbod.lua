
vim.cmd([[
"  数据库配置，格式：'name': '服务器类型://用户名@地址/指定库(可以不指定)',
let g:dbs = {
\ 'MySQL': 'mysql://root@localhost',
\ 'dev': 'postgres://postgres:mypassword@localhost:5432/my-dev-db',
\ 'staging': 'postgres://postgres:mypassword@localhost:5432/my-staging-db',
\ }


" 表帮助程序
let g:db_ui_table_helpers = {
\   'postgresql': {
\     'Count': 'select count(*) from "{table}"',
\     'List': 'select * from "{table}" order by id asc',
\   }
\ }

" 图标
let g:db_ui_icons = {
    \ 'expanded': '▾',
    \ 'collapsed': '▸',
    \ 'saved_query': '*',
    \ 'new_query': '+',
    \ 'tables': '~',
    \ 'buffers': '»',
    \ 'connection_ok': '✓',
    \ 'connection_error': '✕',
    \ }

" 使用nerd字体图标
let g:db_ui_use_nerd_fonts =  1
"let g:db_ui_show_database_icon = 1

" 自动执行查询，如果设置为1 ，则打开任何表将自动执行查询表信息。
let g:db_ui_auto_execute_table_helpers = 1

" 隐藏帮助文本，0隐藏，1显示
let g:db_ui_show_help = 1
" 抽屉宽度
let g:db_ui_winwidth = 40
" 所有查询都写入此文件
let g:db_ui_save_location = '~/.cache/'
" 0映射，1不映射
let g:db_ui_disable_mappings = 0

]])