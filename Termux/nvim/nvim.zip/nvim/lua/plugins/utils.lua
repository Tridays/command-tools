
local ts_utils = require'nvim-treesitter.ts_utils'
local M = {}

--[[
Implements 4 methods:
  get_current_method_name() - return a method name.
  get_current_class_name() - return a class name where the cursor is
  get_current_package_name() - return a package name of the current file
  get_current_full_class_name() - return a full class name (package + class name)
  get_current_full_method_name(delimiter) - return a full method name (package + class + [delimiter] + method name)
--]]

-- Find nodes by type
function find_node_by_type(expr, type_name)
  while expr do
    if expr:type() == type_name then
        break
    end
    expr = expr:parent()
  end
  return expr
end

-- Find child nodes by type
function find_child_by_type(expr, type_name)
  local id = 0
  local expr_child = expr:child(id)
  while expr_child do 
    if expr_child:type() == type_name then
      break
    end
    id = id + 1
    expr_child = expr:child(id)
  end

  return expr_child
end



-- Get Current Method Name
function M.get_current_method_name()
  local current_node = ts_utils.get_node_at_cursor()
  if not current_node then return nil end

  local expr = find_node_by_type(current_node, 'method_declaration')
  if not expr then return nil end

  local child = find_child_by_type(expr, 'identifier')
  if not child then return nil end
  return vim.treesitter.query.get_node_text(child, 0)
end

-- Get Current Class Name
function M.get_current_class_name()
  local current_node = ts_utils.get_node_at_cursor()
  if not current_node then return nil end

  local class_declaration = find_node_by_type(current_node, 'class_declaration')
  if not class_declaration then return nil end
  
  local child = find_child_by_type(class_declaration, 'identifier')
  if not child then return nil end
  return vim.treesitter.query.get_node_text(child, 0)
end



-- Get Current Package Name
function M.get_current_package_name()
  local current_node = ts_utils.get_node_at_cursor()
  if not current_node then return nil end

  local program_expr = find_node_by_type(current_node, 'program')
  if not program_expr then return nil end
  local package_expr = find_child_by_type(program_expr, 'package_declaration')
  if not package_expr then return nil end

  local child = find_child_by_type(package_expr, 'scoped_identifier')
  if not child then return nil end
  return vim.treesitter.query.get_node_text(child, 0)
end

-- Get Current Full Class Name
function M.get_current_full_class_name()
  local package = M.get_current_package_name()
  local class = M.get_current_class_name()
  return package .. '.' .. class
end

-- Get Current Full Method Name with delimiter or default '.'
function M.get_current_full_method_name(delimiter)
  delimiter = delimiter or '.'
  local full_class_name = M.get_current_full_class_name()
  local method_name = M.get_current_method_name()
  return full_class_name .. delimiter .. method_name
end




-- log输出格式化
function logPrint(str)
    str = os.date("\nLog output date: %Y-%m-%d %H:%M:%S \n", os.time()) .. str
    print(str)
end
 
-- key值格式化
function formatKey(key)
    local t = type(key)
    if t == "number" then
        return "["..key.."]"
    elseif t == "string" then
        local n = tonumber(key)
        if n then
            return "["..key.."]"
        end
    end
    return key
end
 
-- 栈
function newStack()
    local stack = {
        tableList = {}
    }
    function stack:push(t)
        table.insert(self.tableList, t)
    end
    function stack:pop()
        return table.remove(self.tableList)
    end
    function stack:contains(t)
        for _, v in ipairs(self.tableList) do
            if v == t then
                return true
            end
        end
        return false
    end
    return stack
end
 
-- 输出打印table表 函数
function printTable(...)
    local args = {...}
    for k, v in pairs(args) do
        local root = v
        if type(root) == "table" then
            local temp = {
                "------------------------ printTable start ------------------------\n",
                "local tableValue".." = {\n",
            }
            local stack = newStack()
            local function table2String(t, depth)
                stack:push(t)
                if type(depth) == "number" then
                    depth = depth + 1
                else
                    depth = 1
                end
                local indent = ""
                for i=1, depth do
                    indent = indent .. "    "
                end
                for k, v in pairs(t) do
                    local key = tostring(k)
                    local typeV = type(v)
                    if typeV == "table" then
                        if key ~= "__valuePrototype" then
                            if stack:contains(v) then
                                table.insert(temp, indent..formatKey(key).." = {检测到循环引用!},\n")
                            else
                                table.insert(temp, indent..formatKey(key).." = {\n")
                                table2String(v, depth)
                                table.insert(temp, indent.."},\n")
                            end
                        end
                    elseif typeV == "string" then
                        table.insert(temp, string.format("%s%s = \"%s\",\n", indent, formatKey(key), tostring(v)))
                    else
                        table.insert(temp, string.format("%s%s = %s,\n", indent, formatKey(key), tostring(v)))
                    end
                end
                stack:pop()
            end
            table2String(root)
            table.insert(temp, "}\n------------------------- printTable end -------------------------")
            logPrint(table.concat(temp))
        else
            logPrint("----------------------- printString start ------------------------\n"
                 .. tostring(root) .. "\n------------------------ printString end -------------------------")
        end
    end
end





--用于marks快捷键绑定的table添加
function M.addKM(t1, t2)
    for key ,var in pairs(t2) do
        if( not (key == "name")) then
            t1[key] = var
        end
    end
    return t1
end



function M.funMarksLog(var)
	if var == 1 then
		T = {
			"说明：",
			"   ●<leader>m[0-9] 即m后面输入0-9之间，就可以标记了",
			"       如：<leader>m6 表示使用第6个书签标记。",
			"   ●<leader>dm 是删除某行书签标记。",
			"       如<leader>dm6 表示清除当前页面所有书签6标记。",
		}
		printTable(T)
	elseif var == 2 then
		T = {
			"常见快捷键说明",
			"   -------------文本操作---------------",
			"   ●<C-A> 自由选中",
			"   ●<C-a> 全部选中",
			"   ●<C-sj> 选中光标到下一行",
			"   ●<C-se> 选中光标到下一个单词/字符之前",
			"   ●<C-x> 更多选中方法",
			"   ●<ESC> 取消选中",
			"   ●<C-c> 复制 ",
			"   ●<C-v> 粘贴 ",
			"   ●<C-d> 删除一行",
			"   ●<C-D> 删除选中",
			"   ●<C-z> 撤销 ",
			"   ●<C-y> 反撤销 ",
			"   ●<C-s> 保存文件",
			"   ●gg 跳到到文本开头",
			"   ●<C-G> 跳到到文本末尾",
			"   ●gcc 单行注释（在n模式下）",
			"   ●gc 多行注释（选中后）",
			"   ●J｜K 下移｜上移选中（选中后）",
			"                         ",
			"   -------------屏幕操作---------------",
			"   ●<leader>sv 左右分屏",
			"   ●<leader>sh 上下分屏",
			"   ●<C-h> 切换到左页面                ",
			"   ●<C-l> 切换到右页面         ↑k     ",
			"   ●<C-k> 切换到上页面    ←h       l→",
			"   ●<C-j> 切换到下页面          ↓j     ",
			"                         ",
			"   -------------目录树tree---------------",
			"   ●a 创建文件｜文件夹",
			"        注意:创建文件夹要在后面追加 / 不然就是创建文件",
			"   ●r 重命名文件｜文件夹",
			"   ●d 删除文件｜文件夹（需要确认）",
			"   ●c 复制文件｜文件夹",
			"   ●x 剪切文件｜文件夹",
			"   ●p 粘贴文件｜文件夹｜路径",
			"   ●E ｜W 展开｜折叠所有目录",
			"   ●<C-v> ｜<Tab>打开｜关闭文件｜文件夹",
			"   ●<C-x> 分屏打开文件",
			"   ●J｜K 移动到目录树底部｜顶部",
			"   ●gy 复制绝对路径",
			"   ●f 过滤器",
			"                         ",
			"   -------------文件差异性比对---------------",
			"   ●:diffthis 开启文件差异对比（和下一个打开文件对比）",
			"   ●:diffsplit file 选择file与当前文件差异对比",
			"   ●nvim -d file1 file2 或者一开始就比对",
		}
		printTable(T)
 	elseif var == 3 then
		T = {
			"dap说明：",
			"   ●:lua print(vim.inspect(require'dap'.configurations.java)) 命令行输入可以查看你的适配器信息",
			"       当你进行调试时，Lsp服务器会提供配置文件，请看准包名再选择调试！",
		}
		printTable(T)
 	elseif var == 4 then
		T = {
			"Lsp说明：",
			"   ●:lua =vim.lsp.get_active_clients() 命令行输入可以查看你的Lsp信息",
			"       $HOME/.workspace/ 是Lsp的项目缓存区，项目不使用时可以自行清理",
			"                         ",
			"   -------------Java语法提示功能说明---------------",
			"    ●Java语法提示→eclipse.jdt.ls支持gradle与maven项目",
			"                         ",
			"   -------------PHP语法提示功能说明---------------",
			"    ●nvim a.php 为什么没有语法提示？",
			"        答：PHP需要有配置文件psalm.xml存在的项目，才进行语法提示",
			"    ●如何创建一个存在配置文件psalm.xml的PHP项目？",
			"        答：mkdir -p $HOME/myphp/src",
			"            touch $HOME/myphp/src/a.php",
			"            cd $HOME/myphp/",
			"            export PATH=$PATH:$HOME/.local/share/nvim/mason/packages/psalm/vendor/bin/",
			"            psalm --init src 3",
			"            psalm",

		}
		printTable(T)
 	elseif var == 5 then
		T = {
			"数据库说明：",
			"   ●数据库连接说明，请查看配置文件",
			"       ~/.config/nvim/lua/plugins/vim-dadbod.lua",
			"   ●",
		}
		printTable(T)
 	else
 		print("M.funMarksLog参数有误！")
	end
end



return M
