require("which-key").setup({}) --默认配置已经很强了，这里就不动了
require("core/keymaps")  --导入自己配置的快捷键
local keymap = vim.keymap.set

--绑定快捷键
--register(mappings, opts)需要两个参数
--[[
●参数``opts``介绍（type：table）
	{
	-- 表示模式，与nvim_set_keymap第一个参数中的模式相同
	  mode = "n", 
	  --前置键，我们触发该条快捷键需要的前置键，一般使用<leader>作为前置键
	  prefix = "",
	  --命令对应的缓冲区id，用它来指定这个绑定作用于某个局部缓冲区
	  buffer = nil, 
	  --同我们之间介绍的 nvim_set_keymap中的 silent含义
	  silent = true, 
	  --快捷键不进行递归传递
	  noremap = true, 
 	 nowait = false,
	}

●参数``mappings``介绍（type：table）
	mappings 中的字段主要用来定义快捷键以及它的显示文字，后面我们通过例子来体会它的具体参数

""终端1 √
""终端2
""终端3
""Java
""A
""
"" debug
""debug-c
""
""undo

--]]
local mappings = {
	--1级目录（小写用完了用大写！）
	a = toolKM,
	b = mysqlKM,
	d = dapKM,
	e = {"开｜关文档树"},
	f = telescopeKM,
	h = helpKM,
	l = {
		name = "Lsp服务｜",
		j = lspKM,
		l = lspsagaKM,
	},
	m = marksKM,
	o = TransKM,
	p = {
		name = "插件｜管理",
		a = packerKM,
		b = masonKM,
		m = markdownKM,

	},
	q = {":qa!<CR>", "不保存文件退出！"},
	s = {
		name = "分屏",
		v = {"左右分屏"},
		h = {"上下分屏"},
	},
	t = terminalKM,
	u = {"撤回操作<C-z>"},
	x = ThemesKM,
	w = {":wq!<cr>", "保存文件退出！"},
	z = zdKM,
}

local opts = {
	prefix = "<leader>",
}


--载入配置
require("which-key").register(mappings, opts)







--[[
一、键表
	<k0> - <k9> 小键盘 0到9
	<S-..> Shift+键
	<C-..> Control+键
	<M-...>  Alt+键或meta+键
	<A-...> 同<M-..>
	<Esc> Escape 键
	<Up>光标上移键
	<Down>光标下移键
	<Space> 插入空格
	<Tab>插入Tab
	<CR> 等于<Enter>
	<cmd> 表示命令行，后面跟要执行的命令

二、在neovim中绑定快捷键的方式
	●原汁原味vim方案
		vim.keymap.set("i", "jk", "<ESC>") -- 说明，i代表插入模式，使用jk代替ESC键
	●新版neovim方案
		--vim的升级款
		vim.keymap.set({"i", "n", "v"}, "<F9>", "<cmd>lua require'dap'.toggle_breakpoint()<CR>", {silent = true, noremap = true, buffer = bufnr}) 
		--neovim提供的方案
		vim.api.nvim_set_keymap('n', 'gD', '<cmd>lua vim.lsp.buf.declaration()<CR>', { noremap=true, silent=true })

三、键盘映射 (Map)介绍
	●在vim配置文件中经常会看到map、nmap、imap、vmap、vnoremap、nunmap、nmapclear等
		（1）nore ——表示非递归，map默认是递归映射的
		（2）n ——表示在普通模式下生效
			如：nmap <leader>s  :wq<CR>   #表示按下了leader键和s键后，执行:wq命令，<CR>代表回车
		（3）v ——表示在可视模式下生效
			 如：vmap <C-c>  +y   #表示在可视模式下，按ctrl+c复制选中的内容
		（4）i ——表示在插入模式下生效
		（5）c ——表示在命令行模式下生效
		（6）un ——后面跟按键组合，表示删除这个映射
			 如：unvmap <C-c>   #删除映射
		（7）clear ——表示清除快捷键映射
			如: mapclear、nmapclear、nnoremapclear等等
	●特殊参数
		（1）<buffer> ——映射将只局限于当前缓冲区（也就是你此时正编辑的文件）内。
			比如： :map <buffer> ,w /a<CR>   #它的意思时在当前缓冲区里定义键绑定，“,w”将在当前缓冲区里查找字符a。
		（2）<silent> ——是指执行键绑定时不在命令行上回显。
			比如： :map <silent> ,w /abcd<CR>   #你在输入,w查找abcd时，命令行上不会显示/abcd，如果没有<silent>参数就会显示出来
		（3）<special>  —— 一般用于定义特殊键怕有副作用的场合。
			比如： :map <special> <F12> /Header<CR>
		（4）<expr>  ——那么参数会作为表达式来进行计算，结果使用实际使用的。
			比如： :inoremap <expr> . InsertDot()   #这可以用来检查光标之前的文本并在一定条件下启动全能 (omni) 补全。 
		（5）<unique>  —— 一般用于定义新的键映射或者缩写命令的同时检查是否该键已经被映射，如果该映射或者缩写已经存在，则该命令会失败。
		（6）有很多具体的映射相关的内容可以参见  :help map
	●快速映射快捷键
		map({"n"}, "<leader>s", ":wq<CR>", {silent = false })
	●查看所有映射
		:nnoremap 或 :vnoremap …等等单独使用命令，会显示当前的映射
	●严格意义上来说，快捷键的绑定应该是键盘映射，将某些键映射为另一些键。



--]]