-- ---------- 全局配置文件 ---------- --
-- 导入基础配置文件 ~/.config/lua/core/option.lua
require("core.options")
-- 导入命令配置文件 ~/.config/lua/core/autocommand.lua
require("core.autocommand")

--vim.opt.runtimepath:append("~/.local/share/nvim/site")
--print(vim.inspect(vim.api.nvim_list_runtime_paths()))  -- 输出runtimepath变量


-- 导入插件的配置文件 ~/.config/lua/plugins/xxx.lua
-- 插件管理器
require("plugins.plugins-setup")  -- 对插件不熟的伙伴可以使用packer插件管理器
--启动页面
require("plugins/dashboard-nvim")
-- 主题
require("plugins/Theme")
-- 状态栏
require("plugins/lualine")
--require("plugins/vim-airline")
-- 文档树
require("plugins/nvim-tree")
-- 语法高亮
require("plugins/treesitter")

-- lsp服务器基本设置
require("lsp/mason")
require("lsp/lsp-colors")
require("lsp/lspsaga")
require("fidget").setup() --lsp右下角信息输出
--启用lsp客户端
require("lsp/python") --Python
require("lsp/lua") --lua
require("lsp/clangd") --c/c++
require("lsp/bashls") --bash
require("lsp/psalm") --php
require("lsp/cssls") --css
require("lsp/gopls") --go
require("lsp/gradle") --gradle
require("lsp/html") --html
require("lsp/jsonls") --json
require("lsp/tsserver") --JavaScript
require("lsp/texlab") --LaTex
require("lsp/zk") --markdown
require("lsp/sqls") --SQL
--dap调试
require("dap/nvim-dap")
require("dap/nvim-dap-ui")
require("dap/nvim-dap-virtual-text")

-- 代码块补全
require("plugins/cmp")
-- 代码块格式化
require("plugins/null-ls")
-- 其他插件
require("plugins/comment") -- gcc和gc注释
require("plugins/autopairs") -- 自动补全括号
require("plugins/bufferline") -- 状态线
require("plugins/gitsigns") --
require("plugins/toggleterm") --浮动终端
require("plugins/telescope") -- 强大的文本搜索
require("plugins/which-key") -- 快捷键提示
require("plugins/marks") -- 一个简单的行标记
require("plugins/Trans") -- 英文翻译
require("plugins/markdown") -- markdown预览
require("plugins/indentLine") -- 缩进线
require("plugins/pets") --小宠物
require("plugins/vim-dadbod") --数据库






--[[
1.java spring项目
2.c/c++调试器
3.bash调试器
--]]

--[[

libpthread-2.31.so => libpthread.so.0
ln -s libdl-2.31.so  libdl.so.2   
ln -s libstdc++.so.6.0.28  libstdc++.so.6
ln -s libm-2.31.so  libm.so.6   
libgcc_s.so.1  libgcc_s.so.1  
ln -s libc-2.31.so  libc.so.6
ld-linux-aarch64.so.1    
--]]
